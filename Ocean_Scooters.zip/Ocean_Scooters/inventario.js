
const pool = require("./db");

async function confirmarPedidoPrueba(pedidoId) {
    const db = await pool.connect();

    try {
        await db.query("BEGIN");

        // Bloquear el pedido mientras se procesa
        const pedidoResult = await db.query(
            `
            SELECT
                id,
                estado,
                pago_estado,
                inventario_descontado
            FROM pedidos
            WHERE id = $1
            FOR UPDATE
            `,
            [pedidoId]
        );

        if (pedidoResult.rows.length === 0) {
            const error = new Error("Pedido no encontrado.");
            error.status = 404;
            throw error;
        }

        const pedido = pedidoResult.rows[0];

        // Evitar descontar dos veces
        if (pedido.inventario_descontado) {
            await db.query("COMMIT");

            return {
                mensaje: "El inventario ya fue descontado.",
                pedidoId,
                yaProcesado: true
            };
        }

        if (pedido.estado === "cancelado") {
            const error = new Error(
                "No se puede confirmar un pedido cancelado."
            );
            error.status = 409;
            throw error;
        }

        // Obtener los productos del pedido
        const detalles = await db.query(
            `
            SELECT producto_id, cantidad
            FROM detalle_pedidos
            WHERE pedido_id = $1
            ORDER BY producto_id
            `,
            [pedidoId]
        );

        if (detalles.rows.length === 0) {
            const error = new Error(
                "El pedido no contiene productos."
            );
            error.status = 409;
            throw error;
        }

        // Agrupar cantidades por producto
        const cantidades = new Map();

        for (const item of detalles.rows) {
            const id = String(item.producto_id);
            const cantidad = Number(item.cantidad);

            cantidades.set(
                id,
                (cantidades.get(id) || 0) + cantidad
            );
        }

        // Descontar existencias sin permitir stock negativo
        for (const id of [...cantidades.keys()].sort()) {
            const cantidad = cantidades.get(id);

            const actualizado = await db.query(
                `
                UPDATE productos
                SET stock = stock - $1
                WHERE id = $2
                  AND activo = TRUE
                  AND stock >= $1
                RETURNING id, nombre, stock
                `,
                [cantidad, id]
            );

            if (actualizado.rows.length === 0) {
                const error = new Error(
                    `No hay existencias suficientes del producto ${id}.`
                );
                error.status = 409;
                throw error;
            }
        }

        // Registrar el resultado como SIMULACIÓN.
        // No marcar pago_estado como aprobado.
        await db.query(
            `
            UPDATE pedidos
            SET inventario_descontado = TRUE,
                estado = 'procesando'
            WHERE id = $1
            `,
            [pedidoId]
        );

        await db.query("COMMIT");

        return {
            mensaje: "Inventario descontado en modo de prueba.",
            pedidoId,
            yaProcesado: false
        };

    } catch (error) {
        try {
            await db.query("ROLLBACK");
        } catch (_) {}

        throw error;
    } finally {
        db.release();
    }
}

module.exports = {
    confirmarPedidoPrueba
};
