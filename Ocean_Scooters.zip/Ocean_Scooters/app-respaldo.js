
require("dotenv").config();

const express = require("express");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");

const {
    MercadoPagoConfig,
    Preference,
    Payment
} = require("mercadopago");

const app = express();

// Rutas de PostgreSQL
const rutasDB = require("./rutas-db");

const PORT = Number(process.env.PORT) || 3000;
const BASE_URL = (
    process.env.BASE_URL || `http://localhost:${PORT}`
).replace(/\/$/, "");

const PUBLIC_DIR = path.join(__dirname, "public");
const DATA_DIR = path.join(__dirname, "data");

const PRODUCT_FILE = path.join(DATA_DIR, "productos.json");
const ORDER_FILE = path.join(DATA_DIR, "pedidos.json");
const SOURCE_PRODUCT_FILE = path.join(__dirname, "productos.json");

const ADMIN_KEY = process.env.ADMIN_KEY || "";
const MP_TOKEN = process.env.MP_ACCESS_TOKEN || "";

const mpClient = MP_TOKEN
    ? new MercadoPagoConfig({ accessToken: MP_TOKEN })
    : null;

// ============================================
// CREAR ARCHIVOS DE DATOS
// ============================================

fs.mkdirSync(DATA_DIR, { recursive: true });

if (!fs.existsSync(PRODUCT_FILE)) {
    const initial = fs.existsSync(SOURCE_PRODUCT_FILE)
        ? fs.readFileSync(SOURCE_PRODUCT_FILE, "utf8")
        : "[]";

    fs.writeFileSync(PRODUCT_FILE, initial);
}

if (!fs.existsSync(ORDER_FILE)) {
    fs.writeFileSync(ORDER_FILE, "[]");
}

// ============================================
// FUNCIONES AUXILIARES
// ============================================

function readArray(file) {
    const result = JSON.parse(
        fs.readFileSync(file, "utf8")
    );

    if (!Array.isArray(result)) {
        throw new Error(
            `El archivo ${file} no contiene una lista`
        );
    }

    return result;
}

function saveArray(file, list) {
    const temp = `${file}.${process.pid}.tmp`;

    fs.writeFileSync(
        temp,
        JSON.stringify(list, null, 2)
    );

    fs.renameSync(temp, file);
}

function money(value) {
    return Math.round(Number(value) * 100) / 100;
}

function publicProduct(product) {
    return {
        ...product,
        disponible: Number(product.stock) > 0
    };
}

function safeEqual(a, b) {
    const aa = Buffer.from(String(a || ""));
    const bb = Buffer.from(String(b || ""));

    return aa.length === bb.length &&
        crypto.timingSafeEqual(aa, bb);
}

function adminOnly(req, res, next) {
    const key = req.get("x-admin-key");

    if (!ADMIN_KEY || !safeEqual(key, ADMIN_KEY)) {
        return res.status(401).json({
            error: "Clave de administrador incorrecta."
        });
    }

    next();
}

function getItemId(item) {
    return String(
        item.id ?? item.productoId ?? ""
    );
}

function getItemQuantity(item) {
    return Number(
        item.cantidad ?? item.quantity
    );
}

function orderItems(order) {
    return order.items || order.productos || [];
}

function orderId(order) {
    return String(order.id);
}

// ============================================
// CONFIGURACIÓN EXPRESS
// ============================================

app.use(express.json({ limit: "50kb" }));

// Conexión de las rutas de PostgreSQL
app.use("/api/db", rutasDB);
app.use(express.static(PUBLIC_DIR));

// ============================================
// PÁGINAS
// ============================================

app.get("/", (req, res) => {
    res.sendFile(
        path.join(PUBLIC_DIR, "index.html")
    );
});

app.get("/admin", (req, res) => {
    res.sendFile(
        path.join(PUBLIC_DIR, "admin.html")
    );
});

// ============================================
// PRODUCTOS DE LA TIENDA
// ============================================

app.get("/api/productos", (req, res) => {
    try {
        const products = readArray(PRODUCT_FILE);

        res.json(
            products.map(publicProduct)
        );
    } catch (error) {
        console.error(error);

        res.status(500).json({
            error: "No se pudieron cargar los productos."
        });
    }
});

// ============================================
// REGISTRAR PEDIDOS
// ============================================

app.post("/api/pedidos", (req, res) => {
    try {
        const body = req.body || {};
        const cliente = body.cliente || {};

        const nombre = String(
            cliente.nombre ?? body.nombre ?? ""
        ).trim();

        const correo = String(
            cliente.correo ?? body.correo ?? ""
        ).trim();

        const telefono = String(
            cliente.telefono ?? body.telefono ?? ""
        ).trim();

        const direccion = String(
            cliente.direccion ?? body.direccion ?? ""
        ).trim();

        const requested = body.items || body.productos || [];

        if (
            !nombre ||
            !correo ||
            !Array.isArray(requested) ||
            !requested.length ||
            requested.length > 30
        ) {
            return res.status(400).json({
                error: "Completa el nombre, correo y los productos del pedido."
            });
        }

        if (
            nombre.length > 120 ||
            correo.length > 254 ||
            telefono.length > 40 ||
            direccion.length > 500 ||
            !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo)
        ) {
            return res.status(400).json({
                error: "Datos del cliente inválidos."
            });
        }

        const catalog = readArray(PRODUCT_FILE);
        const items = [];
        const combined = new Map();

        for (const requestedItem of requested) {
            const id = getItemId(requestedItem);
            const quantity = getItemQuantity(requestedItem);

            if (
                !id ||
                !Number.isSafeInteger(quantity) ||
                quantity < 1 ||
                quantity > 50
            ) {
                return res.status(400).json({
                    error: "Cantidad o producto inválido."
                });
            }

            combined.set(
                id,
                (combined.get(id) || 0) + quantity
            );
        }

        for (const [id, cantidad] of combined) {
            const product = catalog.find(
                p => String(p.id) === id
            );

            if (
                !product ||
                !Number.isFinite(Number(product.precio)) ||
                Number(product.precio) <= 0 ||
                Number(product.stock) < cantidad
            ) {
                return res.status(400).json({
                    error: `Producto ${id} no disponible o sin existencias suficientes.`
                });
            }

            items.push({
                id: product.id,
                nombre: product.nombre,
                precio: money(product.precio),
                cantidad,
                subtotal: money(
                    Number(product.precio) * cantidad
                )
            });
        }

        const total = money(
            items.reduce(
                (sum, item) => sum + item.subtotal,
                0
            )
        );

        const pedido = {
            id: crypto.randomUUID(),
            fecha: new Date().toISOString(),

            cliente: {
                nombre,
                correo,
                telefono,
                direccion
            },

            items,
            productos: items,
            total,

            estado: "pendiente",
            pagoEstado: "pendiente",
            inventarioDescontado: false
        };

        const orders = readArray(ORDER_FILE);

        orders.push(pedido);
        saveArray(ORDER_FILE, orders);

        res.status(201).json({
            mensaje: "Pedido registrado.",
            pedidoId: pedido.id,
            id: pedido.id,
            pedido,
            total
        });

    } catch (error) {
        console.error(error);

        res.status(500).json({
            error: "No se pudo guardar el pedido."
        });
    }
});

// ============================================
// MERCADO PAGO - CREAR PAGO DE PRUEBA
// ============================================

app.post("/api/crear-pago", async (req, res) => {
    try {
        if (!mpClient) {
            return res.status(503).json({
                error: "Mercado Pago no está configurado. Agrega un token de prueba en .env."
            });
        }

        const pedidoId = String(
            req.body?.pedidoId ?? req.body?.id ?? ""
        ).trim();

        if (!pedidoId) {
            return res.status(400).json({
                error: "Falta pedidoId."
            });
        }

        const pedido = readArray(ORDER_FILE).find(
            p => orderId(p) === pedidoId
        );

        if (!pedido) {
            return res.status(404).json({
                error: "Pedido no encontrado."
            });
        }

        if (pedido.pagoEstado === "aprobado") {
            return res.status(409).json({
                error: "Este pedido ya está pagado."
            });
        }

        const catalog = readArray(PRODUCT_FILE);
        const items = [];

        for (const entry of orderItems(pedido)) {
            const product = catalog.find(
                p => String(p.id) === getItemId(entry)
            );

            const quantity = getItemQuantity(entry);

            if (
                !product ||
                !Number.isSafeInteger(quantity) ||
                quantity < 1 ||
                quantity > Number(product.stock)
            ) {
                return res.status(409).json({
                    error: "Un producto del pedido ya no tiene existencias suficientes."
                });
            }

            items.push({
                id: String(product.id),
                title: String(product.nombre),
                quantity,
                unit_price: money(product.precio),
                currency_id: "MXN"
            });
        }

        if (!items.length) {
            return res.status(400).json({
                error: "El pedido no tiene productos."
            });
        }

        const expected = money(
            items.reduce(
                (sum, item) =>
                    sum + item.quantity * item.unit_price,
                0
            )
        );

        if (expected !== money(pedido.total)) {
            return res.status(409).json({
                error: "El precio del pedido cambió. Crea un pedido nuevo."
            });
        }

        const preference = new Preference(mpClient);

        const body = {
            items,
            external_reference: pedido.id,

            back_urls: {
                success: `${BASE_URL}/resultado.html`,
                failure: `${BASE_URL}/resultado.html`,
                pending: `${BASE_URL}/resultado.html`
            }
        };

        // Para recibir notificaciones se necesita
        // una URL pública HTTPS.
        if (process.env.MP_WEBHOOK_URL) {
            body.notification_url =
                process.env.MP_WEBHOOK_URL;
        }

        const response = await preference.create({
            body
        });

        const url =
            response.sandbox_init_point ||
            response.init_point;

        if (!url) {
            return res.status(502).json({
                error: "Mercado Pago no devolvió un enlace de pago."
            });
        }

        res.json({
            pedidoId: pedido.id,
            url,
            init_point: url,
            sandbox_init_point:
                response.sandbox_init_point || null
        });

    } catch (error) {
        console.error("Mercado Pago:", error);

        res.status(502).json({
            error: "No se pudo generar el enlace de pago de prueba."
        });
    }
});

// ============================================
// NOTIFICACIONES MERCADO PAGO
// ============================================

// Esta ruta solo recibe notificaciones.
// No confirma pagos ni descuenta inventario.
// Para producción debe verificarse la firma
// y consultar el pago directamente a Mercado Pago.

app.post("/api/mp/webhook", (req, res) => {
    res.sendStatus(200);
});

// ============================================
// ADMINISTRACIÓN - CONSULTAR PEDIDOS
// ============================================

app.get("/api/admin/pedidos", adminOnly, (req, res) => {
    try {
        res.json(readArray(ORDER_FILE));
    } catch (error) {
        console.error(error);

        res.status(500).json({
            error: "No se pudieron cargar los pedidos."
        });
    }
});

// ============================================
// ADMINISTRACIÓN - CONSULTAR PRODUCTOS
// ============================================

app.get("/api/admin/productos", adminOnly, (req, res) => {
    try {
        res.json(
            readArray(PRODUCT_FILE).map(publicProduct)
        );
    } catch (error) {
        console.error(error);

        res.status(500).json({
            error: "No se pudieron cargar los productos."
        });
    }
});

// ============================================
// ADMINISTRACIÓN - ACTUALIZAR INVENTARIO
// ============================================

app.patch(
    "/api/admin/productos/:id",
    adminOnly,
    (req, res) => {
        try {
            const stock = Number(req.body?.stock);

            if (
                !Number.isSafeInteger(stock) ||
                stock < 0 ||
                stock > 100000
            ) {
                return res.status(400).json({
                    error: "Stock inválido."
                });
            }

            const products = readArray(PRODUCT_FILE);

            const product = products.find(
                p => String(p.id) === req.params.id
            );

            if (!product) {
                return res.status(404).json({
                    error: "Producto no encontrado."
                });
            }

            product.stock = stock;

            saveArray(PRODUCT_FILE, products);

            res.json({
                mensaje: "Inventario actualizado.",
                producto: publicProduct(product)
            });

        } catch (error) {
            console.error(error);

            res.status(500).json({
                error: "No se pudo actualizar el inventario."
            });
        }
    }
);

// ============================================
// ADMINISTRACIÓN - ACTUALIZAR PEDIDOS
// ============================================

app.patch(
    "/api/admin/pedidos/:id",
    adminOnly,
    (req, res) => {
        try {
            const estado = String(
                req.body?.estado ?? ""
            );

            const allowed = [
                "pendiente",
                "procesando",
                "enviado",
                "entregado",
                "cancelado"
            ];

            if (!allowed.includes(estado)) {
                return res.status(400).json({
                    error: "Estado no permitido."
                });
            }

            const orders = readArray(ORDER_FILE);

            const order = orders.find(
                p => orderId(p) === req.params.id
            );

            if (!order) {
                return res.status(404).json({
                    error: "Pedido no encontrado."
                });
            }

            order.estado = estado;

            // Esta ruta no permite aprobar pagos.
            saveArray(ORDER_FILE, orders);

            res.json({
                mensaje: "Estado actualizado.",
                pedido: order
            });

        } catch (error) {
            console.error(error);

            res.status(500).json({
                error: "No se pudo actualizar el pedido."
            });
        }
    }
);

// ============================================
// ERROR 404
// ============================================

app.use((req, res) => {
    res.status(404).json({
        error: "La página o ruta solicitada no existe."
    });
});

// ============================================
// INICIAR SERVIDOR
// ============================================

app.listen(PORT, () => {
    console.log("==================================");
    console.log("       OCEAN SCOOTERS");
    console.log("==================================");

    console.log(`Tienda: ${BASE_URL}`);
    console.log(`Administrador: ${BASE_URL}/admin`);

    console.log(
        `Mercado Pago: ${
            mpClient
                ? "Token configurado; pendiente de verificar"
                : "Sin token de prueba"
        }`
    );
});
