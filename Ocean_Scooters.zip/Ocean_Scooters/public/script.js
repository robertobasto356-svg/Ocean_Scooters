
"use strict";

// ==========================================
// OCEAN SCOOTERS
// CATÁLOGO DINÁMICO DESDE POSTGRESQL
// ==========================================

const API_PRODUCTOS = "/api/productos";

let productosOcean = [];

// ==========================================
// FORMATO DE PRECIOS
// ==========================================

const formatoPrecio = new Intl.NumberFormat(
    "es-MX",
    {
        style: "currency",
        currency: "MXN",
        minimumFractionDigits: 2
    }
);

// ==========================================
// MOSTRAR MENSAJES
// ==========================================

function mostrarMensajeCatalogo(mensaje) {
    const elemento = document.getElementById(
        "mensaje-catalogo"
    );

    if (!elemento) return;

    elemento.textContent = mensaje;
    elemento.hidden = !mensaje;
}

// ==========================================
// CREAR TARJETA DE PRODUCTO
// ==========================================

function crearTarjetaProducto(producto) {
    const tarjeta = document.createElement("article");
    tarjeta.className = "producto-card";

    const enlaceImagen = document.createElement("a");

    enlaceImagen.href =
        "/producto.html?id=" +
        encodeURIComponent(producto.id);

    enlaceImagen.className = "producto-imagen-enlace";

    const imagen = document.createElement("img");

    imagen.src = producto.imagen || "/img/sin-imagen.png";
    imagen.alt = producto.nombre || "Scooter submarino";
    imagen.loading = "lazy";

    imagen.addEventListener("error", () => {
        imagen.removeAttribute("src");
        imagen.alt = "Imagen no disponible";
        imagen.classList.add("imagen-no-disponible");
    }, { once: true });

    enlaceImagen.appendChild(imagen);

    const contenido = document.createElement("div");
    contenido.className = "producto-contenido";

    const categoria = document.createElement("span");
    categoria.className = "producto-categoria";
    categoria.textContent =
        producto.categoria || "Scooter submarino";

    const nombre = document.createElement("h3");
    nombre.className = "producto-nombre";
    nombre.textContent = producto.nombre || "Sin nombre";

    const descripcion = document.createElement("p");
    descripcion.className = "producto-descripcion";
    descripcion.textContent =
        producto.descripcion || "Consulta los detalles del producto.";

    const precio = document.createElement("div");
    precio.className = "producto-precio";
    precio.textContent = formatoPrecio.format(
        Number(producto.precio) || 0
    );

    const disponibilidad = document.createElement("span");

    const disponible =
        producto.disponible === true ||
        (
            producto.activo !== false &&
            Number(producto.stock) > 0
        );

    disponibilidad.className = disponible
        ? "producto-disponible"
        : "producto-agotado";

    disponibilidad.textContent = disponible
        ? "Disponible"
        : "Agotado";

    const boton = document.createElement("a");
    boton.className = "boton-ver-producto";

    boton.href =
        "/producto.html?id=" +
        encodeURIComponent(producto.id);

    boton.textContent = "Ver producto";

    contenido.append(
        categoria,
        nombre,
        descripcion,
        precio,
        disponibilidad,
        boton
    );

    tarjeta.append(enlaceImagen, contenido);

    return tarjeta;
}

// ==========================================
// MOSTRAR PRODUCTOS EN LA PÁGINA
// ==========================================

function mostrarProductos(lista) {
    const contenedor = document.getElementById(
        "catalogo-productos"
    );

    if (!contenedor) {
        console.error(
            "No existe el contenedor #catalogo-productos."
        );
        return;
    }

    contenedor.replaceChildren();

    if (!lista.length) {
        mostrarMensajeCatalogo(
            "No se encontraron productos."
        );
        return;
    }

    mostrarMensajeCatalogo("");

    const fragmento = document.createDocumentFragment();

    lista.forEach(producto => {
        fragmento.appendChild(
            crearTarjetaProducto(producto)
        );
    });

    contenedor.appendChild(fragmento);
}

// ==========================================
// BUSCAR Y ORDENAR
// ==========================================

function filtrarProductos() {
    const buscador = document.getElementById(
        "buscar-producto"
    );

    const selector = document.getElementById(
        "ordenar-productos"
    );

    const busqueda = (
        buscador?.value || ""
    ).toLowerCase().trim();

    const orden = selector?.value || "nombre";

    const filtrados = productosOcean.filter(producto => {
        const texto = [
            producto.nombre,
            producto.descripcion,
            producto.categoria
        ].join(" ").toLowerCase();

        return texto.includes(busqueda);
    });

    if (orden === "precio-menor") {
        filtrados.sort(
            (a, b) =>
                Number(a.precio) - Number(b.precio)
        );
    } else if (orden === "precio-mayor") {
        filtrados.sort(
            (a, b) =>
                Number(b.precio) - Number(a.precio)
        );
    } else {
        filtrados.sort((a, b) =>
            String(a.nombre).localeCompare(
                String(b.nombre),
                "es"
            )
        );
    }

    mostrarProductos(filtrados);
}

// ==========================================
// CARGAR PRODUCTOS DESDE EXPRESS
// ==========================================

async function cargarProductosOcean() {
    mostrarMensajeCatalogo(
        "Cargando scooters submarinos..."
    );

    try {
        const respuesta = await fetch(API_PRODUCTOS, {
            method: "GET",
            headers: {
                "Accept": "application/json"
            },
            cache: "no-store"
        });

        if (!respuesta.ok) {
            throw new Error(
                `Error HTTP ${respuesta.status}`
            );
        }

        const datos = await respuesta.json();

        if (!Array.isArray(datos)) {
            throw new Error(
                "La API no devolvió una lista de productos."
            );
        }

        productosOcean = datos;

        console.log(
            "Productos recibidos desde PostgreSQL:",
            productosOcean
        );

        filtrarProductos();

    } catch (error) {
        console.error(
            "Error al cargar catálogo:",
            error
        );

        mostrarMensajeCatalogo(
            "No se pudo cargar el catálogo. " +
            "Comprueba que el servidor y PostgreSQL estén funcionando."
        );
    }
}

// ==========================================
// MENÚ PARA CELULARES
// ==========================================

function configurarMenu() {
    const boton = document.getElementById(
        "boton-menu"
    );

    const menu = document.getElementById(
        "menu-principal"
    );

    if (!boton || !menu) return;

    boton.addEventListener("click", () => {
        const abierto = menu.classList.toggle(
            "menu-abierto"
        );

        boton.setAttribute(
            "aria-expanded",
            String(abierto)
        );
    });

    menu.querySelectorAll("a").forEach(enlace => {
        enlace.addEventListener("click", () => {
            menu.classList.remove("menu-abierto");

            boton.setAttribute(
                "aria-expanded",
                "false"
            );
        });
    });
}

// ==========================================
// INICIALIZAR PÁGINA
// ==========================================

document.addEventListener(
    "DOMContentLoaded",
    () => {
        const buscador = document.getElementById(
            "buscar-producto"
        );

        const selector = document.getElementById(
            "ordenar-productos"
        );

        buscador?.addEventListener(
            "input",
            filtrarProductos
        );

        selector?.addEventListener(
            "change",
            filtrarProductos
        );

        const anio = document.getElementById(
            "anio-actual"
        );

        if (anio) {
            anio.textContent = new Date().getFullYear();
        }

        configurarMenu();
        cargarProductosOcean();
    }
);
