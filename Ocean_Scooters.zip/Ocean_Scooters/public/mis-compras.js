
"use strict";

const lista = document.getElementById("listaCompras");

const dinero = valor =>
    new Intl.NumberFormat("es-MX", {
        style: "currency",
        currency: "MXN"
    }).format(Number(valor) || 0);

function el(tag, texto = "", clase = "") {
    const nodo = document.createElement(tag);
    nodo.textContent = texto;

    if (clase) {
        nodo.className = clase;
    }

    return nodo;
}

function vacio() {
    lista.replaceChildren();

    const caja = el("section", "", "vacio");

    caja.append(
        el("h2", "Aún no tienes compras pagadas")
    );

    caja.append(
        el(
            "p",
            "Los pedidos aparecerán aquí cuando se confirme " +
            "su pago. Solo se consultan los pedidos guardados " +
            "en este navegador."
        )
    );

    const link = el(
        "a",
        "Explorar productos",
        "boton"
    );

    link.href = "/#productos";

    caja.append(link);
    lista.append(caja);
}

function mostrar(compra) {
    const tarjeta = el("article", "", "pedido");

    const cabecera = el("div", "", "cabecera");
    const encabezado = el("div");

    encabezado.append(
        el(
            "h2",
            `Pedido #${compra.id.slice(0, 8).toUpperCase()}`
        )
    );

    const fecha = compra.fecha
        ? new Date(compra.fecha).toLocaleDateString(
            "es-MX",
            {
                day: "numeric",
                month: "long",
                year: "numeric"
            }
        )
        : "Sin fecha";

    encabezado.append(
        el("p", `Fecha: ${fecha}`, "fecha")
    );

    cabecera.append(
        encabezado,
        el("span", "✓ Pago confirmado", "pagado")
    );

    tarjeta.append(cabecera);

    for (const producto of compra.productos || []) {
        const fila = el("div", "", "fila");
        const descripcion = el("div");

        descripcion.append(
            el("strong", producto.nombre)
        );

        descripcion.append(
            el(
                "span",
                `Cantidad: ${producto.cantidad}`,
                "detalle"
            )
        );

        fila.append(
            descripcion,
            el(
                "span",
                dinero(producto.subtotal),
                "importe"
            )
        );

        tarjeta.append(fila);
    }

    const total = el("div", "", "total");

    total.append(
        el("span", "Total del pedido"),
        el("span", dinero(compra.total))
    );

    tarjeta.append(total);

    const entrega = el("section", "", "entrega");

    entrega.append(
        el("h3", "🚚 Entrega estimada")
    );

    entrega.append(
        el("strong", "20 a 30 días o más")
    );

    entrega.append(
        el(
            "p",
            "Este plazo es orientativo y no garantiza " +
            "una fecha. Puede extenderse según destino, " +
            "disponibilidad y paquetería."
        )
    );

    tarjeta.append(entrega);

    const estado = el("section", "", "estado");

    estado.append(
        el("h3", "Seguimiento")
    );

    estado.append(
        el("p", "✓ Pago aprobado")
    );

    estado.append(
        el(
            "p",
            `📦 Estado del pedido: ${
                compra.estado || "En preparación"
            }`
        )
    );

    tarjeta.append(estado);

    lista.append(tarjeta);
}

async function cargar() {
    let accesos = [];

    try {
        const guardados = JSON.parse(
            localStorage.getItem(
                "ocean_mis_compras"
            ) || "[]"
        );

        if (Array.isArray(guardados)) {
            accesos = guardados.slice(-30);
        }
    } catch {
        // No hay accesos guardados.
    }

    if (!accesos.length) {
        return vacio();
    }

    try {
        const respuesta = await fetch(
            "/api/mis-compras",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    accesos
                })
            }
        );

        const datos = await respuesta.json();

        if (!respuesta.ok) {
            throw new Error(
                datos.error ||
                "No se pudieron consultar las compras."
            );
        }

        if (!datos.compras?.length) {
            return vacio();
        }

        lista.replaceChildren();

        datos.compras.forEach(mostrar);

    } catch (error) {
        lista.replaceChildren(
            el("p", error.message, "error")
        );
    }
}

cargar();
