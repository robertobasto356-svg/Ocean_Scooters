
"use strict";

const $ = s => document.querySelector(s);

const dinero = n =>
    new Intl.NumberFormat("es-MX", {
        style: "currency",
        currency: "MXN"
    }).format(Number(n) || 0);

const estados = [
    "pendiente",
    "procesando",
    "enviado",
    "entregado",
    "cancelado"
];

let productos = [];
let pedidos = [];
let clientes = [];
let editando = null;

// ==========================================
// CREAR ELEMENTOS
// ==========================================

function el(tag, texto, clase) {
    const x = document.createElement(tag);

    if (texto !== undefined) {
        x.textContent = String(texto ?? "");
    }

    if (clase) {
        x.className = clase;
    }

    return x;
}

function boton(texto, accion, clase = "") {
    const x = el("button", texto, clase);

    x.type = "button";
    x.addEventListener("click", accion);

    return x;
}

function aviso(texto, error = false) {
    const x = $("#mensaje");

    x.textContent = texto;
    x.style.color = error ? "#b42318" : "#087db6";
}

// ==========================================
// CONEXIÓN CON EL SERVIDOR
// ==========================================

async function api(url, opts = {}) {
    const respuesta = await fetch(url, {
        credentials: "same-origin",
        ...opts,
        headers: {
            "Content-Type": "application/json",
            ...(opts.headers || {})
        }
    });

    if (respuesta.status === 401) {
        location.href = "/login-admin";
        throw Error("Inicia sesión.");
    }

    const datos = await respuesta.json()
        .catch(() => ({}));

    if (!respuesta.ok) {
        throw Error(
            datos.error ||
            `Error HTTP ${respuesta.status}`
        );
    }

    return datos;
}

async function ejecutar(fn) {
    try {
        await fn();
    } catch (error) {
        aviso(error.message, true);
    }
}

// ==========================================
// NAVEGACIÓN DEL ADMINISTRADOR
// ==========================================

const vistas = [
    "productos",
    "pedidos",
    "resumen",
    "clientes",
    "movimientos"
];

document.querySelectorAll("[data-view]").forEach(b => {
    b.addEventListener("click", () => {
        vistas.forEach(v => {
            $("#view-" + v).classList.toggle(
                "hidden",
                v !== b.dataset.view
            );
        });

        document.querySelectorAll("[data-view]")
            .forEach(x => {
                x.classList.toggle(
                    "active",
                    x === b
                );
            });
    });
});

// ==========================================
// CARACTERÍSTICAS DE PRODUCTOS
// ==========================================

function instalarEspecificaciones() {
    const etiqueta = document.createElement("label");
    etiqueta.className = "full";

    etiqueta.textContent =
        "Características técnicas " +
        "(una por línea, formato Clave: Valor)";

    const campo = document.createElement("textarea");

    campo.id = "pEspecificaciones";

    campo.placeholder =
        "Velocidad: 5 km/h\n" +
        "Autonomía: 90 minutos";

    etiqueta.append(campo);

    $("#pDescripcion").closest("label").after(etiqueta);
}

function especificaciones() {
    const obj = Object.create(null);

    const lineas = $("#pEspecificaciones")
        .value.split(/\r?\n/);

    for (const linea of lineas) {
        if (!linea.trim()) continue;

        const pos = linea.indexOf(":");

        if (pos < 1) {
            throw Error(
                "Usa el formato Característica: Valor."
            );
        }

        const clave = linea.slice(0, pos).trim();
        const valor = linea.slice(pos + 1).trim();

        if (
            !clave ||
            !valor ||
            clave.length > 100 ||
            valor.length > 500 ||
            Object.hasOwn(obj, clave)
        ) {
            throw Error(
                "Revisa las características técnicas."
            );
        }

        obj[clave] = valor;
    }

    if (Object.keys(obj).length > 60) {
        throw Error("Máximo 60 características.");
    }

    return obj;
}

// ==========================================
// FORMULARIO DE PRODUCTOS
// ==========================================

function editor(producto = null) {
    editando = producto?.id || null;

    $("#tituloEditor").textContent = producto
        ? "Editar producto"
        : "Agregar producto";

    const campos = [
        ["pId", "id"],
        ["pNombre", "nombre"],
        ["pPrecio", "precio"],
        ["pStock", "stock"],
        ["pCategoria", "categoria"],
        ["pImagen", "imagen"],
        ["pDescripcion", "descripcion"]
    ];

    for (const [id, clave] of campos) {
        $("#" + id).value =
            producto?.[clave] ??
            (id === "pStock" ? 0 : "");
    }

    $("#pId").readOnly = !!producto;

    $("#pActivo").value = String(
        producto?.activo ?? true
    );

    $("#pEspecificaciones").value =
        Object.entries(
            producto?.especificaciones || {}
        )
        .map(([clave, valor]) => `${clave}: ${valor}`)
        .join("\n");

    $("#formError").textContent = "";

    $("#editor").showModal();
}

function datosProducto(p) {
    return {
        id: p.id,
        nombre: p.nombre,
        precio: Number(p.precio),
        stock: Number(p.stock),
        categoria: p.categoria || "",
        descripcion: p.descripcion || "",
        imagen: p.imagen || "",
        activo: !!p.activo,
        especificaciones: p.especificaciones || {}
    };
}

// ==========================================
// CARGAR PRODUCTOS
// ==========================================

async function cargarProductos() {
    productos = await api("/api/admin/productos");

    $("#statProductos").textContent = productos.length;

    $("#statActivos").textContent =
        productos.filter(p => p.activo).length;

    renderProductos();
}

// ==========================================
// MOSTRAR PRODUCTOS
// ==========================================

function renderProductos() {
    const cuerpo = $("#productos");

    cuerpo.replaceChildren();

    const busqueda = $("#buscar")
        .value.trim().toLowerCase();

    const filtrados = productos.filter(p =>
        `${p.nombre} ${p.id} ${p.categoria || ""}`
            .toLowerCase()
            .includes(busqueda)
    );

    for (const p of filtrados) {
        const fila = el("tr");

        const celdaNombre = el("td");
        const info = el("div", undefined, "prod");

        if (p.imagen) {
            const img = el("img");

            img.src = p.imagen;
            img.alt = p.nombre;

            info.append(img);
        }

        const descripcion = el("div");

        descripcion.append(
            el("strong", p.nombre),
            el("p", p.id)
        );

        info.append(descripcion);
        celdaNombre.append(info);

        const celdaAcciones = el("td");
        const acciones = el(
            "div",
            undefined,
            "actions"
        );

        // EDITAR
        acciones.append(
            boton("Editar", () => editor(p))
        );

        // OCULTAR O ACTIVAR
        acciones.append(
            boton(
                p.activo ? "Ocultar" : "Activar",

                () => ejecutar(async () => {
                    if (
                        !confirm(
                            `¿Cambiar visibilidad de ${p.nombre}?`
                        )
                    ) {
                        return;
                    }

                    await api(
                        `/api/admin/productos/${encodeURIComponent(p.id)}`,
                        {
                            method: "PATCH",
                            body: JSON.stringify({
                                ...datosProducto(p),
                                activo: !p.activo
                            })
                        }
                    );

                    await cargarProductos();

                    aviso("Visibilidad actualizada.");
                }),

                "outline"
            )
        );

        // ELIMINAR
        acciones.append(
            boton(
                "Eliminar",

                () => ejecutar(async () => {
                    if (
                        !confirm(
                            `¿Eliminar ${p.nombre}? ` +
                            "Si tiene pedidos se ocultará " +
                            "para conservar el historial."
                        )
                    ) {
                        return;
                    }

                    const resultado = await api(
                        `/api/admin/productos/${encodeURIComponent(p.id)}`,
                        {
                            method: "DELETE"
                        }
                    );

                    await cargarProductos();

                    aviso(resultado.mensaje);
                }),

                "danger"
            )
        );

        celdaAcciones.append(acciones);

        fila.append(
            celdaNombre,

            el("td", dinero(p.precio)),

            el(
                "td",
                p.stock,
                Number(p.stock) <= 5 && p.activo
                    ? "pill warn"
                    : ""
            ),

            el("td", p.categoria || "—"),

            el(
                "td",
                p.activo ? "Activo" : "Oculto"
            ),

            celdaAcciones
        );

        cuerpo.append(fila);
    }

    if (!cuerpo.children.length) {
        const fila = el("tr");
        const celda = el(
            "td",
            "No hay productos para mostrar."
        );

        celda.colSpan = 6;

        fila.append(celda);
        cuerpo.append(fila);
    }
}

// ==========================================
// GUARDAR PRODUCTO
// ==========================================

async function guardarProducto(evento) {
    evento.preventDefault();

    const guardar = $("#guardar");

    try {
        guardar.disabled = true;

        const producto = {
            id: $("#pId").value.trim(),
            nombre: $("#pNombre").value.trim(),
            precio: Number($("#pPrecio").value),
            stock: Number($("#pStock").value),
            categoria: $("#pCategoria").value.trim(),
            imagen: $("#pImagen").value.trim(),
            descripcion: $("#pDescripcion").value.trim(),
            activo: $("#pActivo").value === "true",
            especificaciones: especificaciones()
        };

        await api(
            editando
                ? `/api/admin/productos/${encodeURIComponent(editando)}`
                : "/api/admin/productos",

            {
                method: editando ? "PATCH" : "POST",
                body: JSON.stringify(producto)
            }
        );

        $("#editor").close();

        await cargarProductos();
        await cargarResumen();

        aviso(
            editando
                ? "Producto actualizado."
                : "Producto agregado."
        );

    } catch (error) {
        $("#formError").textContent = error.message;

    } finally {
        guardar.disabled = false;
    }
}

// ==========================================
// CARGAR PEDIDOS
// ==========================================

async function cargarPedidos() {
    pedidos = await api("/api/admin/pedidos");

    $("#statPedidos").textContent = pedidos.length;

    const contenedor = $("#pedidos");

    contenedor.replaceChildren();

    if (!pedidos.length) {
        contenedor.append(
            el("p", "Aún no hay pedidos.")
        );
        return;
    }

    for (const p of pedidos) {
        const tarjeta = el(
            "article",
            undefined,
            "order"
        );

        const encabezado = el(
            "div",
            undefined,
            "order-top"
        );

        const texto = el("div");

        texto.append(
            el("h3", `Pedido ${p.id}`),

            el(
                "p",
                `${new Date(p.fecha).toLocaleString("es-MX")} · ${dinero(p.total)}`
            ),

            el(
                "p",
                `Pago: ${p.pagoEstado} · Estado: ${p.estado}`
            ),

            el(
                "p",
                `Cliente: ${p.cliente?.nombre || "—"} · ${p.cliente?.correo || "—"}`
            ),

            el(
                "p",
                `Productos: ${(p.items || [])
                    .map(x => `${x.nombre} × ${x.cantidad}`)
                    .join(", ")}`
            )
        );

        encabezado.append(texto);
        tarjeta.append(encabezado);

        const acciones = el(
            "div",
            undefined,
            "order-actions"
        );

        const selector = el("select");

        for (const estado of estados) {
            const opcion = el("option", estado);

            opcion.value = estado;
            opcion.selected = estado === p.estado;

            selector.append(opcion);
        }

        acciones.append(
            selector,

            boton(
                "Guardar estado",

                () => ejecutar(async () => {
                    await api(
                        `/api/admin/pedidos/${encodeURIComponent(p.id)}`,
                        {
                            method: "PATCH",
                            body: JSON.stringify({
                                estado: selector.value
                            })
                        }
                    );

                    await cargarPedidos();
                    await cargarResumen();

                    aviso("Estado actualizado.");
                })
            )
        );

        tarjeta.append(acciones);

        // DATOS DE ENVÍO
        if (p.numeroGuia) {
            tarjeta.append(
                el(
                    "p",
                    `Envío: ${p.paqueteria || "—"} · Guía: ${p.numeroGuia}`
                )
            );
        }

        // FORMULARIO DE ENVÍO
        if (
            p.pagoEstado === "aprobado" &&
            ["procesando", "enviado"].includes(p.estado)
        ) {
            const envio = el(
                "div",
                undefined,
                "order"
            );

            const paqueteria = el("input");
            const guia = el("input");
            const observaciones = el("textarea");

            paqueteria.placeholder = "Paquetería";
            paqueteria.value = p.paqueteria || "";

            guia.placeholder = "Número de guía";
            guia.value = p.numeroGuia || "";

            observaciones.placeholder = "Observaciones";
            observaciones.value =
                p.observacionesEnvio || "";

            envio.append(
                el("h4", "Registrar envío"),

                paqueteria,
                guia,
                observaciones,

                boton(
                    "Guardar envío",

                    () => ejecutar(async () => {
                        await api(
                            `/api/admin/pedidos/${encodeURIComponent(p.id)}/envio`,
                            {
                                method: "PATCH",
                                body: JSON.stringify({
                                    paqueteria:
                                        paqueteria.value.trim(),

                                    numeroGuia:
                                        guia.value.trim(),

                                    observaciones:
                                        observaciones.value.trim()
                                })
                            }
                        );

                        await cargarPedidos();

                        aviso("Envío registrado.");
                    })
                )
            );

            tarjeta.append(envio);
        }

        contenedor.append(tarjeta);
    }
}

// ==========================================
// ESTADÍSTICAS
// ==========================================

async function cargarResumen() {
    const resumen = await api(
        "/api/admin/resumen"
    );

    $("#statStockBajo").textContent =
        resumen.productos.bajo_stock;

    const contenedor = $("#resumenDatos");

    contenedor.replaceChildren();

    const datos = [
        [
            "Ingresos de pagos aprobados",
            dinero(resumen.pedidos.ingresos)
        ],
        [
            "Pedidos pagados",
            resumen.pedidos.pagados
        ],
        [
            "Pedidos pendientes",
            resumen.pedidos.pendientes
        ],
        [
            "Clientes registrados",
            resumen.clientes.total
        ],
        [
            "Productos agotados",
            resumen.productos.agotados
        ],
        [
            "Productos con stock bajo",
            resumen.productos.bajo_stock
        ]
    ];

    for (const [nombre, valor] of datos) {
        const parrafo = el("p");

        parrafo.append(
            el("strong", nombre + ": "),
            el("span", valor)
        );

        contenedor.append(parrafo);
    }

    const vendidos = $("#masVendidos");

    vendidos.replaceChildren();

    for (const producto of resumen.masVendidos) {
        vendidos.append(
            el(
                "p",
                `${producto.nombre}: ${producto.unidades} unidades`
            )
        );
    }

    if (!resumen.masVendidos.length) {
        vendidos.append(
            el("p", "Aún no hay ventas aprobadas.")
        );
    }
}

// ==========================================
// GESTIÓN DE CLIENTES
// ==========================================

async function cargarClientes() {
    clientes = await api(
        "/api/admin/clientes"
    );

    renderClientes();
}

function renderClientes() {
    const busqueda = $("#buscarClientes")
        .value.toLowerCase();

    const tabla = $("#tablaClientes");

    tabla.replaceChildren();

    const filtrados = clientes.filter(c =>
        `${c.nombre} ${c.correo}`
            .toLowerCase()
            .includes(busqueda)
    );

    for (const cliente of filtrados) {
        const fila = el("tr");

        const valores = [
            cliente.nombre,
            cliente.correo,
            cliente.telefono || "—",
            cliente.pedidos,
            dinero(cliente.total_pagado)
        ];

        for (const valor of valores) {
            fila.append(
                el("td", valor)
            );
        }

        tabla.append(fila);
    }
}

// ==========================================
// HISTORIAL DE INVENTARIO
// ==========================================

async function cargarMovimientos() {
    const movimientos = await api(
        "/api/admin/movimientos"
    );

    const tabla = $("#tablaMovimientos");

    tabla.replaceChildren();

    for (const movimiento of movimientos) {
        const fila = el("tr");

        const valores = [
            new Date(
                movimiento.creado_en
            ).toLocaleString("es-MX"),

            movimiento.producto_id,
            movimiento.accion,
            movimiento.stock_anterior ?? "—",
            movimiento.stock_nuevo ?? "—"
        ];

        for (const valor of valores) {
            fila.append(
                el("td", valor)
            );
        }

        tabla.append(fila);
    }
}

// ==========================================
// CONFIGURAR BOTONES
// ==========================================

instalarEspecificaciones();

$("#buscar").addEventListener(
    "input",
    renderProductos
);

$("#buscarClientes").addEventListener(
    "input",
    renderClientes
);

$("#nuevo").onclick = () => editor();

$("#cerrar").onclick = () =>
    $("#editor").close();

$("#cancelar").onclick = () =>
    $("#editor").close();

$("#productoForm").addEventListener(
    "submit",
    guardarProducto
);

// ==========================================
// BOTONES PARA RECARGAR INFORMACIÓN
// ==========================================

const recargas = [
    ["recargar", cargarProductos],
    ["recargarPedidos", cargarPedidos],
    ["recargarResumen", cargarResumen],
    ["recargarClientes", cargarClientes],
    ["recargarMovimientos", cargarMovimientos]
];

for (const [id, funcion] of recargas) {
    $("#" + id).onclick = () =>
        ejecutar(funcion);
}

// ==========================================
// CERRAR SESIÓN
// ==========================================

$("#logout").onclick = () =>
    ejecutar(async () => {
        await api(
            "/api/admin/logout",
            {
                method: "POST"
            }
        );

        location.href = "/login-admin";
    });

// ==========================================
// CARGAR DATOS AL INICIAR
// ==========================================

Promise.allSettled([
    cargarProductos(),
    cargarPedidos(),
    cargarResumen(),
    cargarClientes(),
    cargarMovimientos()
]).then(resultados => {
    const errores = resultados.filter(
        x => x.status === "rejected"
    );

    if (errores.length) {
        aviso(
            errores
                .map(x => x.reason.message)
                .join(" | "),
            true
        );
    }
});

// ==========================================
// FIN DE ADMIN.JS
// OCEAN SCOOTERS
// ==========================================
