
"use strict";

// OCEAN SCOOTERS
// DETALLES DE PRODUCTO DESDE POSTGRESQL

const $ = selector => document.querySelector(selector);

const moneda = new Intl.NumberFormat("es-MX", {
    style: "currency",
    currency: "MXN"
});

function mostrarError(mensaje) {
    const aviso = $("#mensajeProducto");

    if (aviso) {
        aviso.textContent = mensaje;
        aviso.classList.add("error");
        aviso.hidden = false;
    }

    const contenido = $("#contenidoProducto");

    if (contenido) {
        contenido.hidden = true;
    }
}

function normalizarEspecificaciones(datos) {
    if (!datos) return [];

    if (typeof datos === "string") {
        try {
            return normalizarEspecificaciones(
                JSON.parse(datos)
            );
        } catch {
            return datos
                .split(/\r?\n/)
                .filter(linea => linea.includes(":"))
                .map(linea => {
                    const posicion = linea.indexOf(":");

                    return [
                        linea.slice(0, posicion).trim(),
                        linea.slice(posicion + 1).trim()
                    ];
                })
                .filter(([nombre, valor]) =>
                    nombre && valor
                );
        }
    }

    if (Array.isArray(datos)) {
        return datos
            .map(item => {
                if (!item || typeof item !== "object") {
                    return null;
                }

                return [
                    item.nombre || item.caracteristica || "",
                    item.valor || ""
                ];
            })
            .filter(item =>
                item && item[0] && item[1]
            );
    }

    if (typeof datos === "object") {
        return Object.entries(datos)
            .filter(([nombre, valor]) =>
                nombre.trim() &&
                valor !== null &&
                valor !== undefined &&
                String(valor).trim()
            )
            .map(([nombre, valor]) => [
                nombre,
                String(valor)
            ]);
    }

    return [];
}

function mostrarEspecificaciones(datos) {
    const cuerpo = $("#tablaEspecificaciones");
    const aviso = $("#sinEspecificaciones");
    const contenedor = $("#tablaContenedor");

    if (!cuerpo || !aviso || !contenedor) {
        throw new Error(
            "Faltan elementos de la tabla de especificaciones."
        );
    }

    cuerpo.replaceChildren();

    const lista = normalizarEspecificaciones(datos);

    aviso.hidden = lista.length > 0;
    contenedor.hidden = lista.length === 0;

    for (const [nombre, valor] of lista) {
        const fila = document.createElement("tr");

        const encabezado = document.createElement("th");
        encabezado.scope = "row";
        encabezado.textContent = nombre;

        const celda = document.createElement("td");
        celda.textContent = valor;

        fila.append(encabezado, celda);
        cuerpo.appendChild(fila);
    }
}

function mostrarProducto(producto) {
    const campos = {
        nombre: $("#nombreProducto"),
        categoria: $("#categoriaProducto"),
        precio: $("#precioProducto"),
        descripcion: $("#descripcionProducto"),
        estado: $("#estadoProducto"),
        imagen: $("#imagenProducto"),
        mensaje: $("#mensajeProducto"),
        contenido: $("#contenidoProducto")
    };

    for (const [nombre, elemento] of Object.entries(campos)) {
        if (!elemento) {
            throw new Error(
                "Falta el elemento HTML: " + nombre
            );
        }
    }

    campos.nombre.textContent =
        producto.nombre || "Producto sin nombre";

    campos.categoria.textContent =
        producto.categoria || "Scooter submarino";

    campos.precio.textContent = moneda.format(
        Number(producto.precio) || 0
    );

    campos.descripcion.textContent =
        producto.descripcion?.trim() ||
        "Este producto aún no tiene una descripción registrada.";

    const disponible =
        producto.disponible === true ||
        (
            producto.disponible !== false &&
            producto.activo !== false &&
            Number(producto.stock) > 0
        );

    campos.estado.textContent = disponible
        ? "● Disponible"
        : "● Agotado";

    campos.estado.className =
        "detalle-estado " +
        (disponible ? "disponible" : "agotado");

    if (producto.imagen) {
        campos.imagen.src = producto.imagen;
        campos.imagen.alt = producto.nombre || "Scooter submarino";
        campos.imagen.hidden = false;

        campos.imagen.onerror = () => {
            campos.imagen.hidden = true;
        };
    } else {
        campos.imagen.hidden = true;
    }

    mostrarEspecificaciones(
        producto.especificaciones
    );

    campos.mensaje.hidden = true;
    campos.contenido.hidden = false;

    document.title =
        `${producto.nombre} | Ocean Scooters`;
}

async function cargarProducto() {
    const parametros = new URLSearchParams(
        window.location.search
    );

    const id = parametros.get("id");

    if (!id) {
        mostrarError(
            "No se indicó el producto. Regresa al catálogo."
        );
        return;
    }

    const controlador = new AbortController();

    const limite = setTimeout(() => {
        controlador.abort();
    }, 12000);

    try {
        console.log("Buscando producto:", id);

        const respuesta = await fetch("/api/productos", {
            method: "GET",
            headers: {
                Accept: "application/json"
            },
            cache: "no-store",
            signal: controlador.signal
        });

        if (!respuesta.ok) {
            throw new Error(
                "La API respondió con HTTP " + respuesta.status
            );
        }

        const datos = await respuesta.json();

        if (!Array.isArray(datos)) {
            throw new Error(
                "La API no devolvió una lista de productos."
            );
        }

        console.log("Productos recibidos:", datos);

        const producto = datos.find(item =>
            String(item.id) === String(id)
        );

        if (!producto) {
            mostrarError(
                "No se encontró este producto en el catálogo."
            );
            return;
        }

        console.log("Producto encontrado:", producto);

        mostrarProducto(producto);

    } catch (error) {
        console.error(
            "Error al cargar el producto:",
            error
        );

        if (error.name === "AbortError") {
            mostrarError(
                "El servidor tardó demasiado en responder."
            );
        } else {
            mostrarError(
                "No se pudo cargar el producto: " +
                error.message
            );
        }
    } finally {
        clearTimeout(limite);
    }
}

// Iniciar cuando el HTML esté listo
if (document.readyState === "loading") {
    document.addEventListener(
        "DOMContentLoaded",
        cargarProducto
    );
} else {
    cargarProducto();
}
