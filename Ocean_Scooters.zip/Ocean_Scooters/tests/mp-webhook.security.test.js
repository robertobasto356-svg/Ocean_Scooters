"use strict";

// Pruebas aisladas: NO usan PostgreSQL, Mercado Pago ni una cuenta de pagos.
// Ejecutar: node --test tests/mp-webhook.security.test.js

const test = require("node:test");
const assert = require("node:assert/strict");
const { crearWebhookMercadoPago } = require("../mp-webhook");

const ORIGINAL = {
  MP_WEBHOOK_ENABLED: process.env.MP_WEBHOOK_ENABLED,
  MP_WEBHOOK_SECRET: process.env.MP_WEBHOOK_SECRET,
};
const mockPool = {
  connect() { throw new Error("No se debe consultar PostgreSQL"); },
  query() { throw new Error("No se debe consultar PostgreSQL"); }
};

function solicitud({ tipo = "payment", pagoId = "123456789", firma = "", requestId = "" } = {}) {
  return {
    query: { type: tipo, "data.id": pagoId },
    body: {},
    get(nombre) {
      if (nombre === "x-signature") return firma;
      if (nombre === "x-request-id") return requestId;
      return "";
    }
  };
}
async function ejecutar(req) {
  const res = {
    statusCode: null,
    sendStatus(codigo) { this.statusCode = codigo; return this; }
  };
  const handler = crearWebhookMercadoPago({ pool: mockPool, mpClient: {} });
  await handler(req, res);
  return res.statusCode;
}
function ambiente(on) {
  process.env.MP_WEBHOOK_ENABLED = on ? "true" : "false";
  process.env.MP_WEBHOOK_SECRET = "secreto-exclusivamente-falso-para-tests";
}

test.after(() => {
  for (const [nombre, valor] of Object.entries(ORIGINAL)) {
    if (valor === undefined) delete process.env[nombre];
    else process.env[nombre] = valor;
  }
});

test("webhook deshabilitado rechaza toda solicitud (503)", async () => {
  ambiente(false);
  assert.equal(await ejecutar(solicitud()), 503);
});

test("tipo distinto a payment es rechazado (400)", async () => {
  ambiente(true);
  assert.equal(await ejecutar(solicitud({ tipo: "merchant_order" })), 400);
});

test("ID de pago inválido se rechaza (400)", async () => {
  ambiente(true);
  assert.equal(await ejecutar(solicitud({ pagoId: "no-valido" })), 400);
});

test("sin cabeceras de autenticación se rechaza (401)", async () => {
  ambiente(true);
  assert.equal(await ejecutar(solicitud()), 401);
});

test("firma incorrecta se rechaza sin consultar servicios externos (401)", async () => {
  ambiente(true);
  const ts = Date.now().toString();
  assert.equal(await ejecutar(solicitud({
    firma: "ts=" + ts + ",v1=" + "0".repeat(64),
    requestId: "solicitud-falsa-prueba"
  })), 401);
});

test("firma caducada se rechaza (401)", async () => {
  ambiente(true);
  const ts = (Date.now() - 20 * 60 * 1000).toString();
  assert.equal(await ejecutar(solicitud({
    firma: "ts=" + ts + ",v1=" + "0".repeat(64),
    requestId: "solicitud-falsa-prueba"
  })), 401);
});
