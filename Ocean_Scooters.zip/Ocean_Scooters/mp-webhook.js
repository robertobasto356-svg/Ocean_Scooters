"use strict";
const crypto = require("crypto");
const { Payment } = require("mercadopago");

// Verifica una notificación firmada por Mercado Pago, y vuelve a consultar
// el pago con las credenciales del vendedor antes de tocar pedidos.
function crearWebhookMercadoPago({ pool, mpClient }) {
  return async function webhookMercadoPago(req, res) {
    if (process.env.MP_WEBHOOK_ENABLED !== "true" ||
        !mpClient || !process.env.MP_WEBHOOK_SECRET) {
      return res.sendStatus(503);
    }

    const pagoId = String(req.query["data.id"] || "");
    const tipo = String(req.query.type || req.body?.type || "");
    if (tipo !== "payment" || !/^[0-9]{1,30}$/.test(pagoId)) {
      return res.sendStatus(400);
    }

    const signature = String(req.get("x-signature") || "");
    const requestId = String(req.get("x-request-id") || "");
    const pairs = Object.fromEntries(signature.split(",").map(x => x.trim().split("=")));
    const ts = String(pairs.ts || "");
    const v1 = String(pairs.v1 || "");

    if (!requestId || !/^\d{10,16}$/.test(ts) || !/^[a-f0-9]{64}$/i.test(v1)) {
      return res.sendStatus(401);
    }
    const timestampMs = Number(ts) < 1e12 ? Number(ts) * 1000 : Number(ts);
    if (!Number.isFinite(timestampMs) ||
        Math.abs(Date.now() - timestampMs) > 10 * 60 * 1000) {
      return res.sendStatus(401);
    }
    // Plantilla oficial del webhook de pagos de Mercado Pago.
    const manifest = `id:${pagoId};request-id:${requestId};ts:${ts};`;
    const expected = crypto.createHmac("sha256", process.env.MP_WEBHOOK_SECRET)
      .update(manifest).digest();
    if (!crypto.timingSafeEqual(expected, Buffer.from(v1, "hex"))) {
      return res.sendStatus(401);
    }

    let payment;
    try {
      payment = await new Payment(mpClient).get({ id: pagoId });
    } catch (error) {
      console.error("No se pudo consultar el pago en Mercado Pago:", error.message);
      return res.sendStatus(503); // Mercado Pago puede reintentar la notificación.
    }

    const pedidoId = String(payment.external_reference || "");
    const esperadoModoPruebas = process.env.MP_TEST_MODE === "true";
    const modoValido = esperadoModoPruebas ? payment.live_mode === false : payment.live_mode === true;
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(pedidoId)
        || String(payment.id) !== pagoId || !modoValido) {
      console.error("Pago con referencia o modo no esperado:", pagoId);
      return res.sendStatus(422);
    }

    let db;
    try {
      db = await pool.connect();
      await db.query("BEGIN");
      const { rows } = await db.query(
        `SELECT id, estado, pago_estado, total,
                inventario_descontado, reserva_expira_en
           FROM pedidos WHERE id = $1 FOR UPDATE`,
        [pedidoId]
      );
      const pedido = rows[0];
      if (!pedido) {
        await db.query("ROLLBACK");
        return res.sendStatus(422);
      }

      const moneda = String(payment.currency_id || "");
      const importe = Number(payment.transaction_amount);
      const importeCentavos = Math.round(importe * 100);
      const totalCentavos = Math.round(Number(pedido.total) * 100);
      const montoValido = moneda === "MXN" &&
        Number.isFinite(importe) && importe > 0 &&
        importeCentavos === totalCentavos;

      const { rows: yaConfirmados } = await db.query(
        `SELECT pago_id FROM mp_eventos_pago
          WHERE pedido_id = $1 AND resultado = 'confirmado'
          LIMIT 1`,
        [pedidoId]
      );

      let resultado = "informativo";
      if (payment.status === "approved") {
        const mismoPago = yaConfirmados[0]?.pago_id === pagoId;
        if (pedido.pago_estado === "aprobado" && mismoPago) {
          resultado = "confirmado"; // reintento idéntico: idempotente
        } else if (
          pedido.pago_estado === "pendiente" &&
          pedido.estado === "pendiente" &&
          pedido.inventario_descontado === true &&
          pedido.reserva_expira_en &&
          new Date(pedido.reserva_expira_en).getTime() > Date.now() &&
          !yaConfirmados.length &&
          montoValido
        ) {
          await db.query(
            `UPDATE pedidos SET pago_estado='aprobado',
                estado='procesando', reserva_expira_en=NULL
             WHERE id=$1`,
            [pedidoId]
          );
          resultado = "confirmado";
        } else {
          resultado = "revision_manual"; // no entregar ni descontar otra vez
          console.error("Pago aprobado pendiente de conciliación manual:", pagoId, pedidoId);
        }
      }

      await db.query(
        `INSERT INTO mp_eventos_pago
           (pago_id, pedido_id, estado_mp, resultado, importe, moneda)
         VALUES ($1,$2,$3,$4,$5,$6)
         ON CONFLICT (pago_id) DO UPDATE SET
           estado_mp=EXCLUDED.estado_mp,
           resultado=CASE
             WHEN mp_eventos_pago.resultado='confirmado'
             THEN 'confirmado'
             ELSE EXCLUDED.resultado END,
           actualizado_en=NOW()`,
        [pagoId, pedidoId, String(payment.status || "unknown"),
         resultado, Number.isFinite(importe) ? importe : null, moneda]
      );
      await db.query("COMMIT");
      return res.sendStatus(200);
    } catch (error) {
      if (db) await db.query("ROLLBACK").catch(() => {});
      console.error("Error conciliando notificación MP:", error.message);
      return res.sendStatus(503);
    } finally {
      if (db) db.release();
    }
  };
}
module.exports = { crearWebhookMercadoPago };
