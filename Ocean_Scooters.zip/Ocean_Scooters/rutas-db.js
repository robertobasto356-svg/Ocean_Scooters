
const express = require("express");
const pool = require("./db");

const router = express.Router();

// Obtener los productos desde PostgreSQL
router.get("/productos", async (req, res) => {
    try {
        const resultado = await pool.query(`
            SELECT
                id,
                nombre,
                descripcion,
                categoria,
                precio::float8 AS precio,
                stock,
                imagen,
                (stock > 0 AND activo) AS disponible
            FROM productos
            WHERE activo = TRUE
            ORDER BY nombre
        `);

        res.json(resultado.rows);

    } catch (error) {
        console.error(
            "Error consultando PostgreSQL:",
            error.message
        );

        res.status(500).json({
            error: "No se pudieron obtener los productos."
        });
    }
});

// Comprobar conexión con PostgreSQL
router.get("/estado", async (req, res) => {
    try {
        await pool.query("SELECT 1");

        res.json({
            servidor: "Ocean Scooters",
            baseDatos: "PostgreSQL",
            conexion: "correcta"
        });

    } catch (error) {
        res.status(503).json({
            conexion: "error"
        });
    }
});

module.exports = router;
