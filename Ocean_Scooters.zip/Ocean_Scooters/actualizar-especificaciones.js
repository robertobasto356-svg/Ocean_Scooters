
require("dotenv").config();

const pool = require("./db");

async function actualizarEspecificaciones() {
    const id = process.argv[2];

    if (!id) {
        console.log(
            "Uso: node actualizar-especificaciones.js ID"
        );
        return;
    }

    const especificaciones = {
        "Velocidad": "5-15 km/h",
        "Autonomía": "70-120 minutos",
        "Potencia": "4500 W",
        "Capacidad de batería": "13.5 Ah",
        "Batería": "36 V / 13.5 Ah",
        "Tiempo de carga": "5-7 horas",
        "Peso": "13 kg",
        "Longitud": "80 cm",
        "Dimensiones": "80 × 28 × 41 cm",
        "Voltaje de funcionamiento": "36 V",
        "Material": "PP",
        "Marca": "Songxin",
        "Modelo": "V1",
        "Color": "Blanco",
        "Origen": "Guangdong, China",
        "Peso bruto": "16.5 kg",
        "Certificación indicada": "CE, RoHS",
        "Aplicaciones":
            "Natación, buceo, playa y deportes acuáticos"
    };

    try {
        const resultado = await pool.query(
            `UPDATE productos
             SET especificaciones = $1::jsonb
             WHERE id = $2
             RETURNING id, nombre`,
            [JSON.stringify(especificaciones), id]
        );

        if (!resultado.rowCount) {
            console.log(
                "No se encontró un producto con ese ID."
            );
            return;
        }

        console.log(
            "Especificaciones actualizadas:",
            resultado.rows[0]
        );

    } catch (error) {
        console.error(
            "Error al actualizar:",
            error.message
        );
    } finally {
        await pool.end();
    }
}

actualizarEspecificaciones();
