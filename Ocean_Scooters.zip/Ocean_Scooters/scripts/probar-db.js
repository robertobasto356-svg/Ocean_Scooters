
const pool = require("./db");

async function probarConexion() {
    try {
        const resultado = await pool.query(
            "SELECT current_database() AS base_datos, NOW() AS fecha"
        );

        console.log("=================================");
        console.log(" OCEAN SCOOTERS - POSTGRESQL");
        console.log("=================================");
        console.log("Conexión exitosa");
        console.log("Base de datos:", resultado.rows[0].base_datos);
        console.log("Fecha:", resultado.rows[0].fecha);

        const tablas = await pool.query(`
            SELECT tablename
            FROM pg_catalog.pg_tables
            WHERE schemaname = 'public'
            ORDER BY tablename
        `);

        console.log(
            "Tablas encontradas:",
            tablas.rows.map(fila => fila.tablename)
        );

    } catch (error) {
        console.error("Error de conexión:", error.message);
        process.exitCode = 1;
    } finally {
        await pool.end();
    }
}

probarConexion();
