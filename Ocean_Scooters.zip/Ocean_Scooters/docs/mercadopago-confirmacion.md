# Mercado Pago: confirmación automática (BORRADOR, NO PRODUCTIVO)

Este cambio **no habilita pagos reales** ni modifica `main`.

## Preparación en entorno separado
1. Copia una base de datos **de pruebas** sin datos personales reales.
2. Ejecuta `migrations/2026_mercadopago_eventos.sql` una sola vez en esa base.
3. Configura en Render de pruebas: `MP_TEST_MODE=true`, `MP_ACCESS_TOKEN` (credencial de prueba), `MP_WEBHOOK_SECRET` (clave de firma del webhook de la misma aplicación), `MP_WEBHOOK_ENABLED=true`, `BASE_URL` del servicio HTTPS de pruebas. No registres secretos en GitHub.
4. Configura en Mercado Pago el evento **Pagos** y la URL `https://TU-HOST-DE-PRUEBAS/api/mp/webhook`.
5. Comprueba firmas válidas e inválidas, pago pendiente y aprobado, monto/moneda erróneos, idempotencia, confirmación tardía y transacciones simultáneas.
6. Compara la conciliación en `mp_eventos_pago` y `pedidos` antes de continuar.

## Reglas de seguridad implementadas
- El webhook **rechaza peticiones sin firma válida** y consulta el pago con el SDK del vendedor.
- Verifica `external_reference`, `payment.id`, `currency_id='MXN'`, importe exacto, estado y modo de prueba.
- Actualiza pedidos bajo bloqueo transaccional y registra eventos para impedir confirmaciones duplicadas.
- **Si el pedido ya caducó o se canceló, no lo marca pagado ni listo para envío**: guarda el evento como `revision_manual` para conciliación/refund correspondiente.
- Los estados pendientes/rechazados no se convierten en aprobado.

## Bloqueos antes de producción
- **Corregir la política de reservas de 30 minutos**, pues algunos pagos se acreditan después. Evitar ofrecer medios de pago con confirmación diferida mientras no haya una conciliación adecuada.
- Revisar intentos de pago duplicados y conciliación/refunds, métodos de pago parciales y casos de cancelación/reembolso.
- Incorporar pruebas automatizadas y una consulta de conciliación periódica por si se pierde una notificación.
- Revisar credenciales y compatibilidad del SDK con la versión fijada en package-lock.
- Revisar el historial público/privado del repositorio y rotar cualquier secreto expuesto.
- Actualizar el frontend: actualmente solo registra un pedido, **no redirige a Mercado Pago**.
- Validar requisitos de titularidad y edad de la cuenta receptora de pagos.

**No desplegar a producción ni habilitar `MP_WEBHOOK_ENABLED` sin completar estas comprobaciones.**
