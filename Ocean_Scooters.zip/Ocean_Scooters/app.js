
"use strict";

// ==========================================
// OCEAN SCOOTERS
// SERVIDOR PRINCIPAL - APP.JS
// PARTE 1
// ==========================================

// ==========================================
// IMPORTAR DEPENDENCIAS
// ==========================================

require("dotenv").config();

const express = require("express");
const path = require("path");
const helmet = require("helmet");
const { rateLimit } = require("express-rate-limit");
const crypto = require("crypto");
const session = require("express-session");
const PgSession = require("connect-pg-simple")(session);

const {
    MercadoPagoConfig,
    Preference
} = require("mercadopago");

const pool = require("./db");

const {
    notificarNuevoPedido
} = require("./correo");

// ==========================================
// CREAR SERVIDOR
// ==========================================

const app = express();

// ==========================================
// SEGURIDAD GENERAL
// ==========================================

app.use(helmet({
    contentSecurityPolicy: false
}));

const limiteLogin = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 5,
    standardHeaders: "draft-7",
    legacyHeaders: false,
    message: {
        error:
            "Demasiados intentos. Intenta nuevamente en 15 minutos."
    }
});

// ==========================================
// VARIABLES DE CONFIGURACIÓN
// ==========================================

const PORT = Number(process.env.PORT) || 3001;

const BASE_URL = (
    process.env.BASE_URL || `http://localhost:${PORT}`
).replace(/\/$/, "");

const PUBLIC_DIR = path.join(__dirname, "public");

const ADMIN_PASSWORD_HASH =
    process.env.ADMIN_PASSWORD_HASH || "";

const SESSION_SECRET =
    process.env.SESSION_SECRET || "";

const MP_TOKEN =
    process.env.MP_ACCESS_TOKEN || "";

// ==========================================
// VALIDAR CONFIGURACIÓN
// ==========================================

if (!ADMIN_PASSWORD_HASH || SESSION_SECRET.length < 32) {
    throw new Error(
        "Configura ADMIN_PASSWORD_HASH y SESSION_SECRET en .env"
    );
}

// ==========================================
// MERCADO PAGO
// ==========================================

const mpClient = MP_TOKEN
    ? new MercadoPagoConfig({
        accessToken: MP_TOKEN
    })
    : null;

// ==========================================
// CONFIGURACIÓN GENERAL DE EXPRESS
// ==========================================

app.disable("x-powered-by");
if (process.env.NODE_ENV === "production") {
    app.set("trust proxy", 1);
}
/* COMPROBAR QUE EL SERVIDOR ESTÁ ACTIVO */

app.get("/health", async (req, res) => {
    try {
        await pool.query("SELECT 1");

        res.status(200).json({
            estado: "activo",
            baseDatos: "conectada"
        });

    } catch (error) {
        console.error("Error en health check:", error.message);

        res.status(503).json({
            estado: "no disponible"
        });
    }
});

app.use(express.json({
    limit: "50kb"
}));

// Checkout de prueba solo en ambiente local/de ensayo, nunca público.
app.get("/api/estado-checkout", (req, res) => {
    res.set("Cache-Control", "no-store");
    res.json({
        pruebasHabilitadas:
            process.env.NODE_ENV !== "production" &&
            process.env.MP_TEST_MODE === "true" &&
            Boolean(mpClient)
    });
});

// ==========================================
// SESIONES DEL ADMINISTRADOR
// ==========================================

app.use(session({
    store: new PgSession({
        pool,
        tableName: "sesiones_admin",
        createTableIfMissing: true
    }),

    name: "ocean_admin",

    secret: SESSION_SECRET,

    resave: false,

    saveUninitialized: false,

    cookie: {
        httpOnly: true,
        sameSite: "lax",
        secure: process.env.NODE_ENV === "production",
        maxAge: 60 * 60 * 1000
    }
}));

// ==========================================
// VERIFICAR CONTRASEÑA DEL ADMINISTRADOR
// ==========================================

function verificarPassword(password) {
    try {
        const [saltHex, hashHex] =
            ADMIN_PASSWORD_HASH.split(":");

        if (
            !/^[0-9a-f]+$/i.test(saltHex) ||
            !/^[0-9a-f]+$/i.test(hashHex)
        ) {
            return false;
        }

        const esperado = Buffer.from(hashHex, "hex");

        if (esperado.length !== 64) {
            return false;
        }

        const recibido = crypto.scryptSync(
            password,
            Buffer.from(saltHex, "hex"),
            esperado.length
        );

        return crypto.timingSafeEqual(
            esperado,
            recibido
        );

    } catch {
        return false;
    }
}

// ==========================================
// PROTEGER PÁGINAS DEL ADMINISTRADOR
// ==========================================

function adminPageOnly(req, res, next) {
    if (req.session?.admin === true) {
        return next();
    }

    return res.redirect("/login-admin.html");
}

// ==========================================
// PROTEGER RUTAS API DEL ADMINISTRADOR
// ==========================================

function adminOnly(req, res, next) {
    if (req.session?.admin === true) {
        return next();
    }

    return res.status(401).json({
        error:
            "Acceso denegado. Debes iniciar sesión como administrador."
    });
}

// ==========================================
// VERIFICAR ORIGEN DE PETICIONES
// ==========================================

function sameOrigin(req, res, next) {
    const origin = req.get("origin");

    const expected =
        `${req.protocol}://${req.get("host")}`;

    if (!origin || origin !== expected) {
        return res.status(403).json({
            error: "Origen no autorizado."
        });
    }

    next();
}

// ==========================================
// MANEJAR ERRORES DEL SERVIDOR
// ==========================================

function errorServidor(res, error, mensaje) {
    console.error(mensaje, error);

    res.status(500).json({
        error: mensaje
    });
}

// ==========================================
// VALIDAR UUID
// ==========================================

function esUUID(valor) {
    return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i
        .test(String(valor));
}

// ==========================================
// REDONDEAR PRECIOS
// ==========================================

function redondearDinero(valor) {
    return Math.round(Number(valor) * 100) / 100;
}

// ==========================================
// COLUMNAS DE PRODUCTOS
// ==========================================

const columnasProducto = `
    id,
    nombre,
    descripcion,
    categoria,
    precio::float8 AS precio,
    stock,
    imagen,
    activo,
    COALESCE(
        especificaciones,
        '{}'::jsonb
    ) AS especificaciones,
    (stock > 0 AND activo) AS disponible
`;

// ==========================================
// PÁGINAS DEL ADMINISTRADOR
// ==========================================

// Proteger el JavaScript del administrador.

app.get("/admin.js", adminPageOnly, (req, res) => {
    res.set("Cache-Control", "no-store");

    res.sendFile(
        path.join(PUBLIC_DIR, "admin.js")
    );
});

// Evitar acceso directo al archivo HTML.

app.use((req, res, next) => {
    if (req.path === "/admin.html") {
        return res.sendStatus(404);
    }

    next();
});

// ==========================================
// ARCHIVOS PÚBLICOS
// ==========================================

app.use(express.static(PUBLIC_DIR, {
    index: false
}));

// ==========================================
// PÁGINA PRINCIPAL
// ==========================================

app.get("/", (req, res) => {
    res.sendFile(
        path.join(PUBLIC_DIR, "index.html")
    );
});

// ==========================================
// PÁGINA DE INICIO DE SESIÓN
// ==========================================

app.get("/login-admin", (req, res) => {
    res.sendFile(
        path.join(PUBLIC_DIR, "login-admin.html")
    );
});

// ==========================================
// PANEL DE ADMINISTRADOR
// ==========================================

app.get("/admin", adminPageOnly, (req, res) => {
    res.set("Cache-Control", "no-store");

    res.sendFile(
        path.join(PUBLIC_DIR, "admin.html")
    );
});

// ==========================================
// CONTROL DE INTENTOS DE INICIO DE SESIÓN
// ==========================================

const intentosLogin = new Map();

// ==========================================
// INICIAR SESIÓN COMO ADMINISTRADOR
// ==========================================

app.post(
    "/api/admin/login",
    sameOrigin,
    limiteLogin,
    (req, res) => {

        const ip = req.ip;
        const ahora = Date.now();

        const registro = intentosLogin.get(ip) || {
            intentos: 0,
            bloqueoHasta: 0
        };

        if (registro.bloqueoHasta > ahora) {
            return res.status(429).json({
                error:
                    "Demasiados intentos. Espera 15 minutos."
            });
        }

        const password = req.body?.password;

        if (
            typeof password !== "string" ||
            password.length > 256 ||
            !verificarPassword(password)
        ) {
            registro.intentos++;

            if (registro.intentos >= 5) {
                registro.intentos = 0;
                registro.bloqueoHasta =
                    ahora + 15 * 60 * 1000;
            }

            intentosLogin.set(ip, registro);

            return res.status(401).json({
                error: "Contraseña incorrecta."
            });
        }

        intentosLogin.delete(ip);

        req.session.regenerate(error => {
            if (error) {
                return res.status(500).json({
                    error: "No se pudo iniciar sesión."
                });
            }

            req.session.admin = true;

            req.session.save(error => {
                if (error) {
                    return res.status(500).json({
                        error:
                            "No se pudo guardar la sesión."
                    });
                }

                res.json({
                    mensaje: "Inicio de sesión correcto."
                });
            });
        });
    }
);

// ==========================================
// CERRAR SESIÓN
// ==========================================

app.post(
    "/api/admin/logout",
    adminOnly,
    sameOrigin,
    (req, res) => {

        req.session.destroy(error => {
            if (error) {
                return res.status(500).json({
                    error: "No se pudo cerrar sesión."
                });
            }

            res.clearCookie("ocean_admin");

            res.json({
                mensaje: "Sesión cerrada."
            });
        });
    }
);

// ==========================================
// COMPROBAR CONEXIÓN CON POSTGRESQL
// ==========================================

app.get(
    "/api/db/estado",
    adminOnly,
    async (req, res) => {

        try {
            await pool.query("SELECT 1");

            res.json({
                servidor: "Ocean Scooters",
                baseDatos: "PostgreSQL",
                conexion: "correcta"
            });

        } catch (error) {
            errorServidor(
                res,
                error,
                "No se pudo conectar con PostgreSQL."
            );
        }
    }
);

// ==========================================
// CATÁLOGO PÚBLICO
// ==========================================

async function cargarCatalogo(req, res) {
    try {
        const resultado = await pool.query(`
            SELECT ${columnasProducto}
            FROM productos
            WHERE activo = TRUE
            ORDER BY nombre
        `);

        res.set("Cache-Control", "no-store");

        res.json(resultado.rows);

    } catch (error) {
        errorServidor(
            res,
            error,
            "No se pudieron cargar los productos."
        );
    }
}

// ==========================================
// RUTAS PÚBLICAS DE PRODUCTOS
// ==========================================

app.get("/api/productos", cargarCatalogo);

app.get("/api/db/productos", cargarCatalogo);

// ==========================================
// FIN DE LA PARTE 1
// CONTINÚA PEGANDO LA PARTE 2 DEBAJO
// ==========================================

// ==========================================
// OCEAN SCOOTERS - APP.JS
// PARTE 2 DE 5
// RESERVAS, INVENTARIO Y PEDIDOS
// ==========================================

// ==========================================
// RESERVAS DE INVENTARIO (30 MINUTOS)
// ==========================================

const RESERVA_MINUTOS = 30;

let limpiezaEnCurso = false;

// ==========================================
// DEVOLVER INVENTARIO RESERVADO
// ==========================================

// Esta función debe ejecutarse dentro de una
// transacción con el pedido bloqueado.
//
// inventario_descontado indica que las unidades
// ya fueron descontadas del stock disponible.

async function devolverReserva(db, pedidoId) {

    const detalles = await db.query(
        `SELECT producto_id, cantidad
         FROM detalle_pedidos
         WHERE pedido_id = $1
         ORDER BY producto_id`,
        [pedidoId]
    );

    for (const item of detalles.rows) {

        await db.query(
            `UPDATE productos
             SET stock = stock + $1
             WHERE id = $2`,
            [
                item.cantidad,
                item.producto_id
            ]
        );
    }

    await db.query(
        `UPDATE pedidos
         SET inventario_descontado = FALSE,
             reserva_expira_en = NULL
         WHERE id = $1`,
        [pedidoId]
    );
}

// ==========================================
// LIBERAR RESERVAS VENCIDAS
// ==========================================

// SKIP LOCKED permite ejecutar el mantenimiento
// sin duplicar devoluciones de inventario.

async function expirarReservas() {

    if (limpiezaEnCurso) return;

    limpiezaEnCurso = true;

    let db;

    try {

        db = await pool.connect();

        for (let i = 0; i < 100; i++) {

            await db.query("BEGIN");

            try {

                const resultado = await db.query(
                    `SELECT id
                     FROM pedidos
                     WHERE reserva_expira_en <= NOW()
                       AND inventario_descontado = TRUE
                       AND pago_estado = 'pendiente'
                       AND estado = 'pendiente'
                     ORDER BY reserva_expira_en, id
                     LIMIT 1
                     FOR UPDATE SKIP LOCKED`
                );

                if (!resultado.rows.length) {
                    await db.query("COMMIT");
                    break;
                }

                const id = resultado.rows[0].id;

                await devolverReserva(db, id);

                await db.query(
                    `UPDATE pedidos
                     SET estado = 'cancelado'
                     WHERE id = $1`,
                    [id]
                );

                await db.query("COMMIT");

            } catch (error) {

                await db.query("ROLLBACK")
                    .catch(() => {});

                throw error;
            }
        }

    } catch (error) {

        console.error(
            "No se pudieron liberar reservas vencidas:",
            error
        );

    } finally {

        if (db) {
            db.release();
        }

        limpiezaEnCurso = false;
    }
}

// ==========================================
// LIMPIEZA AUTOMÁTICA DE RESERVAS
// ==========================================

// Revisar reservas aproximadamente cada minuto.

const intervaloReservas = setInterval(
    expirarReservas,
    60 * 1000
);

intervaloReservas.unref();

// Revisar reservas al iniciar el servidor.

expirarReservas();

// ==========================================
// REGISTRAR PEDIDOS
// ==========================================

app.post("/api/pedidos", async (req, res) => {

    const body = req.body || {};

    const cliente = body.cliente || {};

    const nombre = String(
        cliente.nombre ?? body.nombre ?? ""
    ).trim();

    const correo = String(
        cliente.correo ?? body.correo ?? ""
    ).trim();

    const telefono = String(
        cliente.telefono ?? body.telefono ?? ""
    ).trim();

    const direccion = String(
        cliente.direccion ?? body.direccion ?? ""
    ).trim();

    const solicitados =
        body.items ?? body.productos ?? [];

    // ======================================
    // VALIDAR DATOS DEL CLIENTE
    // ======================================

    if (
        !nombre ||
        nombre.length > 120 ||
        !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo) ||
        correo.length > 254 ||
        telefono.length > 30 ||
        direccion.length > 2000 ||
        !Array.isArray(solicitados) ||
        solicitados.length === 0 ||
        solicitados.length > 30
    ) {

        return res.status(400).json({
            error: "Datos del pedido inválidos."
        });
    }

    // ======================================
    // VALIDAR CANTIDADES
    // ======================================

    const cantidades = new Map();

    for (const item of solicitados) {

        const id = String(
            item?.id ?? item?.productoId ?? ""
        );

        const cantidad = Number(
            item?.cantidad ?? item?.quantity
        );

        if (
            !id ||
            id.length > 100 ||
            !Number.isSafeInteger(cantidad) ||
            cantidad < 1 ||
            cantidad > 50
        ) {

            return res.status(400).json({
                error: "Producto o cantidad inválida."
            });
        }

        cantidades.set(
            id,
            (cantidades.get(id) || 0) + cantidad
        );
    }

    if (
        [...cantidades.values()].some(
            cantidad => cantidad > 50
        )
    ) {

        return res.status(400).json({
            error: "Máximo 50 unidades por producto."
        });
    }

    // ======================================
    // LIBERAR RESERVAS VENCIDAS
    // ======================================

    await expirarReservas();

    let db;

    try {

        db = await pool.connect();

        await db.query("BEGIN");

        const items = [];

        // ==================================
        // RESERVAR PRODUCTOS
        // ==================================

        // Orden fijo de bloqueos para reducir
        // conflictos entre pedidos simultáneos.

        for (
            const [id, cantidad] of
            [...cantidades].sort(
                (a, b) => a[0].localeCompare(b[0])
            )
        ) {

            // UPDATE condicional atómico:
            // evita que el stock sea negativo.

            const resultado = await db.query(
                `UPDATE productos
                 SET stock = stock - $2
                 WHERE id = $1
                   AND activo = TRUE
                   AND stock >= $2
                   AND precio > 0
                 RETURNING
                    id,
                    nombre,
                    precio::float8 AS precio`,
                [id, cantidad]
            );

            const producto = resultado.rows[0];

            if (
                !producto ||
                !Number.isFinite(producto.precio)
            ) {

                await db.query("ROLLBACK");

                return res.status(409).json({
                    error:
                        `Producto ${id} sin existencias suficientes.`
                });
            }

            items.push({
                id: producto.id,
                nombre: producto.nombre,
                precio: redondearDinero(
                    producto.precio
                ),
                cantidad,
                subtotal: redondearDinero(
                    producto.precio * cantidad
                )
            });
        }

        // ==================================
        // CALCULAR TOTAL
        // ==================================

        const total = redondearDinero(
            items.reduce(
                (suma, item) =>
                    suma + item.subtotal,
                0
            )
        );

        const pedidoId = crypto.randomUUID();

        // ==================================
        // REGISTRAR CLIENTE
        // ==================================

        const clienteDB = await db.query(
            `INSERT INTO clientes
                (nombre, correo, telefono, direccion)
             VALUES ($1, $2, $3, $4)
             RETURNING id`,
            [
                nombre,
                correo,
                telefono,
                direccion
            ]
        );

        // ==================================
        // CREAR PEDIDO CON RESERVA
        // ==================================

        await db.query(
            `INSERT INTO pedidos
                (id, cliente_id, total,
                 estado, pago_estado,
                 inventario_descontado,
                 reserva_expira_en)
             VALUES
                ($1, $2, $3,
                 'pendiente', 'pendiente',
                 TRUE,
                 NOW() + INTERVAL '30 minutes')`,
            [
                pedidoId,
                clienteDB.rows[0].id,
                total
            ]
        );

        // ==================================
        // GUARDAR DETALLES DEL PEDIDO
        // ==================================

        for (const item of items) {

            await db.query(
                `INSERT INTO detalle_pedidos
                    (pedido_id, producto_id,
                     cantidad, precio_unitario,
                     subtotal)
                 VALUES ($1, $2, $3, $4, $5)`,
                [
                    pedidoId,
                    item.id,
                    item.cantidad,
                    item.precio,
                    item.subtotal
                ]
            );
        }

        // ==================================
        // CONFIRMAR TRANSACCIÓN
        // ==================================

        await db.query("COMMIT");

        const pedido = {
            id: pedidoId,
            fecha: new Date().toISOString(),

            cliente: {
                nombre,
                correo,
                telefono,
                direccion
            },

            items,
            productos: items,
            total,

            estado: "pendiente",
            pagoEstado: "pendiente",

            inventarioDescontado: true,
            reservaMinutos: RESERVA_MINUTOS
        };

        // ==================================
        // RESPONDER AL CLIENTE
        // ==================================

        res.status(201).json({
            mensaje: "Pedido registrado.",
            id: pedidoId,
            pedidoId,
            pedido,
            total
        });

        // ==================================
        // CORREOS AUTOMÁTICOS
        // ==================================

        // Se envían después de guardar el pedido.
        // No modifican el estado del pago.

        notificarNuevoPedido(pedido)
            .then(resultado => {

                console.log(
                    "Notificaciones del pedido:",
                    pedido.id,
                    resultado
                );

            })
            .catch(error => {

                console.error(
                    "Error inesperado en notificaciones:",
                    error.message
                );

            });

    } catch (error) {

        if (db) {
            await db.query("ROLLBACK")
                .catch(() => {});
        }

        if (!res.headersSent) {
            errorServidor(
                res,
                error,
                "No se pudo registrar el pedido."
            );
        }

    } finally {

        if (db) {
            db.release();
        }
    }
});

// ==========================================
// FIN DE LA PARTE 2
// CONTINÚA PEGANDO LA PARTE 3 DEBAJO
// ==========================================

// ==========================================
// OCEAN SCOOTERS - APP.JS
// PARTE 3 DE 5
// ADMINISTRACIÓN DE PRODUCTOS
// ==========================================

// ==========================================
// OBTENER PEDIDOS
// ==========================================

async function obtenerPedidos() {

    const resultado = await pool.query(`
        SELECT
            p.id,
            p.fecha,
            p.total::float8 AS total,
            p.estado,
            p.pago_estado AS "pagoEstado",
            p.inventario_descontado
                AS "inventarioDescontado",
            p.reserva_expira_en AS "reservaExpiraEn",
            p.paqueteria,
            p.numero_guia AS "numeroGuia",
            p.fecha_envio AS "fechaEnvio",
            p.observaciones_envio
                AS "observacionesEnvio",
            c.nombre,
            c.correo,
            c.telefono,
            c.direccion
        FROM pedidos p
        JOIN clientes c
            ON c.id = p.cliente_id
        ORDER BY p.fecha DESC
        LIMIT 200
    `);

    const pedidos = resultado.rows;

    if (!pedidos.length) {
        return [];
    }

    const detalles = await pool.query(
        `SELECT
            d.pedido_id,
            d.producto_id AS id,
            d.cantidad,
            d.precio_unitario::float8 AS precio,
            d.subtotal::float8 AS subtotal,
            COALESCE(
                pr.nombre,
                d.producto_id
            ) AS nombre
         FROM detalle_pedidos d
         LEFT JOIN productos pr
            ON pr.id = d.producto_id
         WHERE d.pedido_id = ANY($1::uuid[])`,
        [pedidos.map(p => p.id)]
    );

    const agrupados = new Map();

    for (const item of detalles.rows) {

        const id = String(item.pedido_id);

        if (!agrupados.has(id)) {
            agrupados.set(id, []);
        }

        agrupados.get(id).push({
            id: item.id,
            nombre: item.nombre,
            cantidad: item.cantidad,
            precio: item.precio,
            subtotal: item.subtotal
        });
    }

    return pedidos.map(p => {

        const items =
            agrupados.get(String(p.id)) || [];

        return {
            id: p.id,
            fecha: p.fecha,
            total: p.total,
            estado: p.estado,
            pagoEstado: p.pagoEstado,
            inventarioDescontado:
                p.inventarioDescontado,
            reservaExpiraEn: p.reservaExpiraEn,
            paqueteria: p.paqueteria,
            numeroGuia: p.numeroGuia,
            fechaEnvio: p.fechaEnvio,
            observacionesEnvio:
                p.observacionesEnvio,

            cliente: {
                nombre: p.nombre,
                correo: p.correo,
                telefono: p.telefono,
                direccion: p.direccion
            },

            items,
            productos: items
        };
    });
}

// ==========================================
// ADMIN: CONSULTAR PRODUCTOS
// ==========================================

app.get(
    "/api/admin/productos",
    adminOnly,
    async (req, res) => {

        try {

            const resultado = await pool.query(`
                SELECT ${columnasProducto}
                FROM productos
                ORDER BY nombre
            `);

            res.json(resultado.rows);

        } catch (error) {

            errorServidor(
                res,
                error,
                "No se pudieron cargar los productos."
            );
        }
    }
);

// ==========================================
// ADMIN: CONSULTAR PEDIDOS
// ==========================================

app.get(
    "/api/admin/pedidos",
    adminOnly,
    async (req, res) => {

        try {

            const pedidos = await obtenerPedidos();

            res.json(pedidos);

        } catch (error) {

            errorServidor(
                res,
                error,
                "No se pudieron cargar los pedidos."
            );
        }
    }
);

// ==========================================
// VALIDAR PRODUCTOS
// ==========================================

function validarProducto(body, nuevo = false) {

    const id = String(
        body?.id ?? ""
    ).trim();

    const nombre = String(
        body?.nombre ?? ""
    ).trim();

    const descripcion = String(
        body?.descripcion ?? ""
    ).trim();

    const categoria = String(
        body?.categoria ?? ""
    ).trim();

    const imagen = String(
        body?.imagen ?? ""
    ).trim();

    const precio = Number(body?.precio);
    const stock = Number(body?.stock);
    const activo = body?.activo;

    let especificaciones = body?.especificaciones;

    if (especificaciones === undefined) {

        especificaciones = nuevo ? {} : null;

    } else if (
        !especificaciones ||
        typeof especificaciones !== "object" ||
        Array.isArray(especificaciones) ||
        Object.keys(especificaciones).length > 60 ||
        Object.entries(especificaciones).some(
            ([clave, valor]) =>
                clave.length < 1 ||
                clave.length > 100 ||
                typeof valor !== "string" ||
                valor.length > 500
        ) ||
        JSON.stringify(especificaciones).length > 12000
    ) {

        return {
            error:
                "Especificaciones inválidas (máximo 60 características)."
        };
    }

    // ======================================
    // VALIDAR ID DEL PRODUCTO
    // ======================================

    if (
        nuevo &&
        !/^[a-zA-Z0-9_-]{1,100}$/.test(id)
    ) {

        return {
            error:
                "ID inválido. Usa letras, números o guiones."
        };
    }

    // ======================================
    // VALIDAR NOMBRE
    // ======================================

    if (
        !nombre ||
        nombre.length > 200
    ) {

        return {
            error: "El nombre es obligatorio."
        };
    }

    // ======================================
    // VALIDAR DESCRIPCIÓN Y CATEGORÍA
    // ======================================

    if (
        descripcion.length > 5000 ||
        categoria.length > 100
    ) {

        return {
            error:
                "Descripción o categoría demasiado larga."
        };
    }

    // ======================================
    // VALIDAR IMAGEN
    // ======================================

    if (
        imagen.length > 2048 ||
        (
            imagen &&
            !/^(https?:\/\/|\/[^/])/i.test(imagen)
        )
    ) {

        return {
            error:
                "La imagen debe ser una URL o ruta local válida."
        };
    }

    // ======================================
    // VALIDAR PRECIO
    // ======================================

    if (
        body?.precio === "" ||
        body?.precio == null ||
        !Number.isFinite(precio) ||
        precio <= 0 ||
        precio > 10000000 ||
        Math.round(precio * 100) / 100 !== precio
    ) {

        return {
            error:
                "Precio inválido. Máximo dos decimales."
        };
    }

    // ======================================
    // VALIDAR STOCK
    // ======================================

    if (
        body?.stock === "" ||
        body?.stock == null ||
        !Number.isSafeInteger(stock) ||
        stock < 0 ||
        stock > 100000
    ) {

        return {
            error:
                "Las existencias deben ser un número entero válido."
        };
    }

    // ======================================
    // VALIDAR ESTADO
    // ======================================

    if (typeof activo !== "boolean") {

        return {
            error:
                "Estado del producto inválido."
        };
    }

    return {
        producto: {
            id,
            nombre,
            descripcion,
            categoria,
            imagen,
            precio,
            stock,
            activo,
            especificaciones
        }
    };
}

// ==========================================
// ADMIN: AGREGAR PRODUCTO
// ==========================================

app.post(
    "/api/admin/productos",
    adminOnly,
    sameOrigin,
    async (req, res) => {

        const { producto, error } =
            validarProducto(req.body, true);

        if (error) {
            return res.status(400).json({
                error
            });
        }

        try {

            const resultado = await pool.query(
                `INSERT INTO productos
                    (id, nombre, descripcion,
                     categoria, precio, stock,
                     imagen, activo, especificaciones)
                 VALUES
                    ($1, $2, $3, $4,
                     $5, $6, $7, $8, $9::jsonb)
                 RETURNING ${columnasProducto}`,
                [
                    producto.id,
                    producto.nombre,
                    producto.descripcion,
                    producto.categoria,
                    producto.precio,
                    producto.stock,
                    producto.imagen,
                    producto.activo,
                    JSON.stringify(
                        producto.especificaciones
                    )
                ]
            );

            res.status(201).json({
                mensaje:
                    "Producto agregado correctamente.",
                producto: resultado.rows[0]
            });

        } catch (error) {

            if (error.code === "23505") {

                return res.status(409).json({
                    error:
                        "Ya existe un producto con ese ID."
                });
            }

            errorServidor(
                res,
                error,
                "No se pudo agregar el producto."
            );
        }
    }
);

// ==========================================
// ADMIN: EDITAR PRODUCTO
// ==========================================

app.patch(
    "/api/admin/productos/:id",
    adminOnly,
    sameOrigin,
    async (req, res) => {

        const { producto, error } =
            validarProducto(req.body);

        if (error) {
            return res.status(400).json({
                error
            });
        }

        try {

            const resultado = await pool.query(
                `UPDATE productos
                 SET nombre = $1,
                     descripcion = $2,
                     categoria = $3,
                     precio = $4,
                     stock = $5,
                     imagen = $6,
                     activo = $7,
                     especificaciones = COALESCE(
                         $9::jsonb,
                         especificaciones
                     )
                 WHERE id = $8
                 RETURNING ${columnasProducto}`,
                [
                    producto.nombre,
                    producto.descripcion,
                    producto.categoria,
                    producto.precio,
                    producto.stock,
                    producto.imagen,
                    producto.activo,
                    req.params.id,
                    producto.especificaciones === null
                        ? null
                        : JSON.stringify(
                            producto.especificaciones
                        )
                ]
            );

            if (!resultado.rows.length) {

                return res.status(404).json({
                    error:
                        "Producto no encontrado."
                });
            }

            res.json({
                mensaje:
                    "Producto actualizado correctamente.",
                producto: resultado.rows[0]
            });

        } catch (error) {

            errorServidor(
                res,
                error,
                "No se pudo actualizar el producto."
            );
        }
    }
);

// ==========================================
// ADMIN: ELIMINAR PRODUCTO
// ==========================================

// Si el producto no tiene pedidos, se elimina
// físicamente de PostgreSQL.
//
// Si tiene pedidos, se desactiva para retirarlo
// del catálogo público sin romper el historial.

app.delete(
    "/api/admin/productos/:id",
    adminOnly,
    sameOrigin,
    async (req, res) => {

        const id = String(
            req.params.id || ""
        ).trim();

        if (!id || id.length > 100) {

            return res.status(400).json({
                error: "ID de producto inválido."
            });
        }

        let db;

        try {

            db = await pool.connect();

            await db.query("BEGIN");

            // ==================================
            // BUSCAR Y BLOQUEAR EL PRODUCTO
            // ==================================

            const resultado = await db.query(
                `SELECT id, nombre, activo
                 FROM productos
                 WHERE id = $1
                 FOR UPDATE`,
                [id]
            );

            if (!resultado.rows.length) {

                await db.query("ROLLBACK");

                return res.status(404).json({
                    error:
                        "El producto no existe."
                });
            }

            const producto = resultado.rows[0];

            // ==================================
            // REVISAR HISTORIAL DE PEDIDOS
            // ==================================

            const historial = await db.query(
                `SELECT EXISTS (
                    SELECT 1
                    FROM detalle_pedidos
                    WHERE producto_id = $1
                ) AS tiene_pedidos`,
                [id]
            );

            const tienePedidos =
                historial.rows[0].tiene_pedidos;

            // ==================================
            // PRODUCTO CON PEDIDOS
            // ==================================

            if (tienePedidos) {

                await db.query(
                    `UPDATE productos
                     SET activo = FALSE
                     WHERE id = $1`,
                    [id]
                );

                await db.query("COMMIT");

                return res.json({
                    mensaje:
                        `El producto "${producto.nombre}" ` +
                        "fue retirado del catálogo. " +
                        "Se conserva su historial de pedidos.",
                    eliminado: false,
                    oculto: true,
                    productoId: id
                });
            }

            // ==================================
            // PRODUCTO SIN PEDIDOS
            // ==================================

            await db.query(
                `DELETE FROM productos
                 WHERE id = $1`,
                [id]
            );

            await db.query("COMMIT");

            return res.json({
                mensaje:
                    `Producto "${producto.nombre}" ` +
                    "eliminado definitivamente.",
                eliminado: true,
                oculto: false,
                productoId: id
            });

        } catch (error) {

            if (db) {

                await db.query("ROLLBACK")
                    .catch(() => {});
            }

            errorServidor(
                res,
                error,
                "No se pudo eliminar el producto."
            );

        } finally {

            if (db) {
                db.release();
            }
        }
    }
);

// ==========================================
// FIN DE LA PARTE 3
// CONTINÚA PEGANDO LA PARTE 4 DEBAJO
// ==========================================

// ==========================================
// OCEAN SCOOTERS - APP.JS
// PARTE 4 DE 5
// ADMINISTRACIÓN DE PEDIDOS Y ENVÍOS
// ==========================================

// ==========================================
// ADMIN: CAMBIAR ESTADO DE PEDIDO
// ==========================================

app.patch(
    "/api/admin/pedidos/:id",
    adminOnly,
    sameOrigin,
    async (req, res) => {

        const estado = String(
            req.body?.estado || ""
        );

        // ==================================
        // ESTADOS PERMITIDOS
        // ==================================

        const permitidos = [
            "pendiente",
            "procesando",
            "enviado",
            "entregado",
            "cancelado"
        ];

        if (!permitidos.includes(estado)) {

            return res.status(400).json({
                error: "Estado no permitido."
            });
        }

        // ==================================
        // VALIDAR ID DEL PEDIDO
        // ==================================

        if (!esUUID(req.params.id)) {

            return res.status(400).json({
                error: "ID de pedido inválido."
            });
        }

        let db;

        try {

            db = await pool.connect();

            await db.query("BEGIN");

            // ==================================
            // BUSCAR Y BLOQUEAR PEDIDO
            // ==================================

            const resultado = await db.query(
                `SELECT
                    estado,
                    pago_estado,
                    inventario_descontado,
                    reserva_expira_en
                 FROM pedidos
                 WHERE id = $1
                 FOR UPDATE`,
                [req.params.id]
            );

            const pedido = resultado.rows[0];

            if (!pedido) {

                await db.query("ROLLBACK");

                return res.status(404).json({
                    error: "Pedido no encontrado."
                });
            }

            // ==================================
            // VALIDAR CAMBIOS DE ESTADO
            // ==================================

            if (
                (
                    pedido.estado === "cancelado" &&
                    estado !== "cancelado"
                ) ||
                (
                    [
                        "procesando",
                        "enviado",
                        "entregado"
                    ].includes(estado) &&
                    pedido.pago_estado !== "aprobado"
                ) ||
                (
                    estado === "cancelado" &&
                    pedido.pago_estado === "aprobado"
                ) ||
                (
                    pedido.reserva_expira_en &&
                    new Date(
                        pedido.reserva_expira_en
                    ) <= new Date() &&
                    pedido.pago_estado === "pendiente" &&
                    estado !== "cancelado"
                )
            ) {

                await db.query("ROLLBACK");

                return res.status(409).json({
                    error:
                        "Cambio no permitido por pago, " +
                        "cancelación o reserva vencida."
                });
            }

            // ==================================
            // DEVOLVER INVENTARIO AL CANCELAR
            // ==================================

            // Si se cancela una reserva pendiente,
            // devolver las unidades al inventario.

            if (
                estado === "cancelado" &&
                pedido.estado !== "cancelado" &&
                pedido.inventario_descontado &&
                pedido.reserva_expira_en
            ) {

                await devolverReserva(
                    db,
                    req.params.id
                );
            }

            // ==================================
            // ACTUALIZAR ESTADO DEL PEDIDO
            // ==================================

            await db.query(
                `UPDATE pedidos
                 SET estado = $1
                 WHERE id = $2`,
                [
                    estado,
                    req.params.id
                ]
            );

            // ==================================
            // CONFIRMAR CAMBIOS
            // ==================================

            await db.query("COMMIT");

            res.json({
                mensaje:
                    "Estado del pedido actualizado."
            });

        } catch (error) {

            if (db) {

                await db.query("ROLLBACK")
                    .catch(() => {});
            }

            errorServidor(
                res,
                error,
                "No se pudo actualizar el pedido."
            );

        } finally {

            if (db) {
                db.release();
            }
        }
    }
);

// ==========================================
// ADMIN: REGISTRAR ENVÍO
// ==========================================

app.patch(
    "/api/admin/pedidos/:id/envio",
    adminOnly,
    sameOrigin,
    async (req, res) => {

        // ==================================
        // OBTENER DATOS DEL ENVÍO
        // ==================================

        const {
            paqueteria,
            numeroGuia,
            observaciones
        } = req.body || {};

        const empresa = String(
            paqueteria || ""
        ).trim();

        const guia = String(
            numeroGuia || ""
        ).trim();

        const notas = String(
            observaciones || ""
        ).trim();

        // ==================================
        // VALIDAR ID DEL PEDIDO
        // ==================================

        if (!esUUID(req.params.id)) {

            return res.status(400).json({
                error: "ID de pedido inválido."
            });
        }

        // ==================================
        // VALIDAR DATOS DEL ENVÍO
        // ==================================

        if (
            !empresa ||
            !guia ||
            empresa.length > 100 ||
            guia.length > 150 ||
            notas.length > 2000
        ) {

            return res.status(400).json({
                error:
                    "Revisa los datos del envío."
            });
        }

        try {

            // ==================================
            // GUARDAR INFORMACIÓN DEL ENVÍO
            // ==================================

            const resultado = await pool.query(
                `UPDATE pedidos
                 SET paqueteria = $1,
                     numero_guia = $2,
                     observaciones_envio = $3,
                     fecha_envio = COALESCE(
                         fecha_envio,
                         NOW()
                     ),
                     estado = 'enviado'
                 WHERE id = $4
                   AND pago_estado = 'aprobado'
                   AND estado IN (
                       'procesando',
                       'enviado'
                   )
                 RETURNING
                     id,
                     estado,
                     paqueteria,
                     numero_guia,
                     fecha_envio`,
                [
                    empresa,
                    guia,
                    notas,
                    req.params.id
                ]
            );

            // ==================================
            // COMPROBAR RESULTADO
            // ==================================

            if (!resultado.rows.length) {

                return res.status(409).json({
                    error:
                        "El pedido no existe o todavía " +
                        "no tiene un pago aprobado."
                });
            }

            // ==================================
            // RESPONDER AL ADMINISTRADOR
            // ==================================

            res.json({
                mensaje:
                    "Envío registrado correctamente.",
                envio: resultado.rows[0]
            });

        } catch (error) {

            errorServidor(
                res,
                error,
                "No se pudo registrar el envío."
            );
        }
    }
);

// ==========================================
// FIN DE LA PARTE 4
// CONTINÚA PEGANDO LA PARTE 5 DEBAJO
// ==========================================

// ==========================================
// OCEAN SCOOTERS - APP.JS
// PARTE 5 DE 5
// MERCADO PAGO Y SERVIDOR
// ==========================================

// ==========================================
// MERCADO PAGO: SOLO PRUEBAS
// ==========================================

app.post("/api/crear-pago", async (req, res) => {

    // ======================================
    // COMPROBAR CONFIGURACIÓN
    // ======================================

    if (
        !mpClient ||
        process.env.MP_TEST_MODE !== "true" ||
        process.env.NODE_ENV === "production"
    ) {

        return res.status(503).json({
            error:
                "Mercado Pago de pruebas no está configurado."
        });
    }

    // ======================================
    // OBTENER ID DEL PEDIDO
    // ======================================

    const pedidoId = String(
        req.body?.pedidoId ??
        req.body?.id ??
        ""
    );

    // ======================================
    // VALIDAR ID DEL PEDIDO
    // ======================================

    if (!esUUID(pedidoId)) {

        return res.status(400).json({
            error: "ID de pedido inválido."
        });
    }

    try {

        // ==================================
        // LIBERAR RESERVAS VENCIDAS
        // ==================================

        await expirarReservas();

        // ==================================
        // CONSULTAR PEDIDO
        // ==================================

        const resultado = await pool.query(
            `SELECT
                id,
                total::float8 AS total,
                pago_estado,
                estado,
                inventario_descontado,
                reserva_expira_en
             FROM pedidos
             WHERE id = $1`,
            [pedidoId]
        );

        const pedido = resultado.rows[0];

        if (!pedido) {

            return res.status(404).json({
                error: "Pedido no encontrado."
            });
        }

        // ==================================
        // VALIDAR RESERVA
        // ==================================

        if (
            pedido.pago_estado !== "pendiente" ||
            pedido.estado !== "pendiente" ||
            !pedido.inventario_descontado ||
            !pedido.reserva_expira_en ||
            new Date(pedido.reserva_expira_en) <= new Date()
        ) {

            return res.status(409).json({
                error:
                    "Este pedido no tiene una reserva vigente " +
                    "o no admite nuevos pagos."
            });
        }

        // ==================================
        // CONSULTAR PRODUCTOS DEL PEDIDO
        // ==================================

        const detalles = await pool.query(
            `SELECT
                d.producto_id AS id,
                d.cantidad,
                d.precio_unitario::float8 AS precio,
                pr.nombre,
                pr.activo
             FROM detalle_pedidos d
             JOIN productos pr
                ON pr.id = d.producto_id
             WHERE d.pedido_id = $1`,
            [pedidoId]
        );

        // ==================================
        // VALIDAR PRODUCTOS ACTIVOS
        // ==================================

        if (
            !detalles.rows.length ||
            detalles.rows.some(
                producto => !producto.activo
            )
        ) {

            return res.status(409).json({
                error:
                    "Uno o más productos ya no están disponibles."
            });
        }

        // ==================================
        // PREPARAR PRODUCTOS PARA MERCADO PAGO
        // ==================================

        const items = detalles.rows.map(producto => ({
            id: String(producto.id),
            title: producto.nombre,
            quantity: producto.cantidad,
            unit_price: redondearDinero(
                producto.precio
            ),
            currency_id: "MXN"
        }));

        // ==================================
        // CALCULAR TOTAL DEL PEDIDO
        // ==================================

        const total = redondearDinero(
            items.reduce(
                (suma, item) =>
                    suma +
                    item.quantity * item.unit_price,
                0
            )
        );

        // ==================================
        // COMPROBAR TOTAL
        // ==================================

        if (
            total !== redondearDinero(pedido.total)
        ) {

            return res.status(409).json({
                error:
                    "El total del pedido no coincide."
            });
        }

        // ==================================
        // CREAR PREFERENCIA DE PAGO
        // ==================================

        const preferencia = new Preference(mpClient);

        const respuesta = await preferencia.create({
            body: {
                items,

                external_reference: pedidoId,

                back_urls: {
                    success:
                        `${BASE_URL}/resultado.html`,

                    failure:
                        `${BASE_URL}/resultado.html`,

                    pending:
                        `${BASE_URL}/resultado.html`
                }
            }
        });

        // ==================================
        // OBTENER ENLACE DE PAGO
        // ==================================

        const url =
            respuesta.sandbox_init_point ||
            respuesta.init_point;

        if (!url) {

            return res.status(502).json({
                error:
                    "Mercado Pago no devolvió un enlace."
            });
        }

        // ==================================
        // RESPONDER AL CLIENTE
        // ==================================

        res.json({
            pedidoId,
            url,
            init_point: url,
            sandbox_init_point:
                respuesta.sandbox_init_point || null
        });

    } catch (error) {

        errorServidor(
            res,
            error,
            "No se pudo crear el pago de prueba."
        );
    }
});

// ==========================================
// WEBHOOK DE MERCADO PAGO
// ==========================================

// IMPORTANTE:
//
// Este webhook todavía NO confirma pagos.
//
// La confirmación segura de pagos reales
// se implementará posteriormente.
//
// No se debe modificar pago_estado desde
// una notificación sin verificar el pago
// directamente con Mercado Pago.

// El webhook permanece deshabilitado salvo configuración explícita.
const { crearWebhookMercadoPago } = require("./mp-webhook");
app.post("/api/mp/webhook", crearWebhookMercadoPago({ pool, mpClient }));

// ==========================================
// ADMIN: ESTADÍSTICAS GENERALES
// ==========================================

app.get(
    "/api/admin/resumen",
    adminOnly,
    async (req, res) => {
        try {
            const productos = await pool.query(`
                SELECT
                    COUNT(*)::int AS total,
                    COUNT(*) FILTER (
                        WHERE activo = TRUE
                    )::int AS activos,
                    COUNT(*) FILTER (
                        WHERE activo = TRUE
                          AND stock = 0
                    )::int AS agotados,
                    COUNT(*) FILTER (
                        WHERE activo = TRUE
                          AND stock BETWEEN 1 AND 5
                    )::int AS bajo_stock
                FROM productos
            `);

            const pedidos = await pool.query(`
                SELECT
                    COUNT(*)::int AS total,
                    COUNT(*) FILTER (
                        WHERE pago_estado = 'aprobado'
                    )::int AS pagados,
                    COUNT(*) FILTER (
                        WHERE pago_estado = 'pendiente'
                    )::int AS pendientes,
                    COALESCE(
                        SUM(total) FILTER (
                            WHERE pago_estado = 'aprobado'
                        ),
                        0
                    )::float8 AS ingresos
                FROM pedidos
            `);

            const clientes = await pool.query(`
                SELECT COUNT(*)::int AS total
                FROM clientes
            `);

            const masVendidos = await pool.query(`
                SELECT
                    COALESCE(
                        pr.nombre,
                        d.producto_id::text
                    ) AS nombre,
                    SUM(d.cantidad)::int AS unidades
                FROM detalle_pedidos d
                JOIN pedidos p
                    ON p.id = d.pedido_id
                LEFT JOIN productos pr
                    ON pr.id = d.producto_id
                WHERE p.pago_estado = 'aprobado'
                GROUP BY
                    d.producto_id,
                    pr.nombre
                ORDER BY unidades DESC
                LIMIT 10
            `);

            res.json({
                productos: productos.rows[0],
                pedidos: pedidos.rows[0],
                clientes: clientes.rows[0],
                masVendidos: masVendidos.rows
            });

        } catch (error) {
            errorServidor(
                res,
                error,
                "No se pudieron cargar las estadísticas."
            );
        }
    }
);

// ==========================================
// ADMIN: CONSULTAR CLIENTES
// ==========================================

app.get(
    "/api/admin/clientes",
    adminOnly,
    async (req, res) => {
        try {
            const resultado = await pool.query(`
                SELECT
                    c.id,
                    c.nombre,
                    c.correo,
                    c.telefono,
                    COUNT(p.id)::int AS pedidos,
                    COALESCE(
                        SUM(p.total) FILTER (
                            WHERE p.pago_estado = 'aprobado'
                        ),
                        0
                    )::float8 AS total_pagado
                FROM clientes c
                LEFT JOIN pedidos p
                    ON p.cliente_id = c.id
                GROUP BY
                    c.id,
                    c.nombre,
                    c.correo,
                    c.telefono
                ORDER BY c.nombre
                LIMIT 500
            `);

            res.json(resultado.rows);

        } catch (error) {
            errorServidor(
                res,
                error,
                "No se pudieron cargar los clientes."
            );
        }
    }
);

// ==========================================
// ADMIN: HISTORIAL DE INVENTARIO
// ==========================================

app.get(
    "/api/admin/movimientos",
    adminOnly,
    async (req, res) => {
        try {
            const resultado = await pool.query(`
                SELECT
                    id,
                    producto_id,
                    accion,
                    stock_anterior,
                    stock_nuevo,
                    detalle,
                    creado_en
                FROM auditoria_productos
                ORDER BY creado_en DESC, id DESC
                LIMIT 200
            `);

            res.json(resultado.rows);

        } catch (error) {
            errorServidor(
                res,
                error,
                "No se pudo cargar el historial de inventario."
            );
        }
    }
);

// ==========================================
// FIN DE LAS NUEVAS RUTAS
// ==========================================

// ==========================================
// RUTA NO ENCONTRADA - ERROR 404
// ==========================================

app.use((req, res) => {

    res.status(404).json({
        error:
            "La página o ruta solicitada no existe."
    });
});

// ==========================================
// INICIAR SERVIDOR
// ==========================================

app.listen(PORT, "0.0.0.0", () => {

    console.log("==================================");
    console.log("          OCEAN SCOOTERS");
    console.log("==================================");

    console.log(`Tienda: ${BASE_URL}`);

    console.log(
        `Administrador: ${BASE_URL}/admin`
    );

    console.log("Base de datos: PostgreSQL");

    console.log(
        "Administrador: protegido con contraseña"
    );

    console.log(
        "Reservas de inventario:",
        `${RESERVA_MINUTOS} minutos`
    );

    console.log(
        "Limpieza automática de reservas:",
        "cada 60 segundos"
    );

    console.log(
        "Mercado Pago:",
        mpClient &&
        process.env.MP_TEST_MODE === "true"
            ? "Pruebas configuradas"
            : "Pruebas no configuradas"
    );

    console.log(
        "Correos:",
        process.env.SMTP_USER
            ? "Configuración SMTP detectada"
            : "Pendiente de configurar"
    );

    console.log("==================================");
    console.log("Servidor iniciado correctamente.");
});

// ==========================================
// FIN DE APP.JS
// OCEAN SCOOTERS
// ==========================================
