
require("dotenv").config();

const nodemailer = require("nodemailer");

// ==========================================
// CONFIGURACIÓN SMTP DE ICLOUD
// ==========================================

const SMTP_HOST =
    process.env.SMTP_HOST || "smtp.mail.me.com";

const SMTP_PORT =
    Number(process.env.SMTP_PORT || 587);

const SMTP_USER = process.env.SMTP_USER;
const SMTP_PASS = process.env.SMTP_PASS;

const CORREO_ADMIN = process.env.CORREO_ADMIN;

const transporter = nodemailer.createTransport({
    host: SMTP_HOST,
    port: SMTP_PORT,
    secure: false,
    requireTLS: true,
    auth: {
        user: SMTP_USER,
        pass: SMTP_PASS
    }
});

// ==========================================
// FUNCIONES AUXILIARES
// ==========================================

function escaparHTML(valor) {
    return String(valor ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}

function formatoPrecio(precio) {
    return new Intl.NumberFormat("es-MX", {
        style: "currency",
        currency: "MXN"
    }).format(Number(precio) || 0);
}

// ==========================================
// DISEÑO DEL CORREO
// ==========================================

function plantillaCorreo(titulo, contenido) {
    return `
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
    </head>

    <body style="
        margin:0;
        padding:25px;
        background:#edf6fc;
        font-family:Arial,sans-serif;
        color:#17344a;
    ">

        <div style="
            max-width:600px;
            margin:auto;
            background:#ffffff;
            border-radius:14px;
            overflow:hidden;
        ">

            <div style="
                background:#0879ba;
                padding:28px;
                text-align:center;
                color:white;
            ">
                <h1>OCEAN SCOOTERS</h1>
                <p>Tu aventura comienza en el agua</p>
            </div>

            <div style="padding:28px">
                <h2>${escaparHTML(titulo)}</h2>
                ${contenido}
            </div>

            <div style="
                background:#f1f6f9;
                padding:20px;
                text-align:center;
                font-size:13px;
                color:#64748b;
            ">
                <p>Ocean Scooters</p>
                <p>Este es un mensaje automático.</p>
            </div>

        </div>

    </body>
    </html>
    `;
}

// ==========================================
// ENVIAR CORREO
// ==========================================

async function enviarCorreo(destinatario, asunto, html) {
    if (!SMTP_USER || !SMTP_PASS) {
        throw new Error(
            "Faltan las credenciales SMTP en .env"
        );
    }

    return transporter.sendMail({
        from: {
            name: "Ocean Scooters",
            address: SMTP_USER
        },
        to: destinatario,
        subject: asunto,
        html
    });
}

// ==========================================
// NOTIFICACIÓN DE NUEVO PEDIDO
// ==========================================

async function notificarNuevoPedido(pedido) {

    const cliente = pedido.cliente || {};

    const productos =
        pedido.items || pedido.productos || [];

    const filas = productos.map(producto => `
        <tr>
            <td style="padding:10px;border-bottom:1px solid #ddd">
                ${escaparHTML(producto.nombre)}
            </td>

            <td style="padding:10px;border-bottom:1px solid #ddd">
                ${Number(producto.cantidad)}
            </td>

            <td style="padding:10px;border-bottom:1px solid #ddd">
                ${formatoPrecio(producto.subtotal)}
            </td>
        </tr>
    `).join("");

    const tabla = `
        <table style="
            width:100%;
            border-collapse:collapse;
            margin:20px 0;
        ">
            <thead>
                <tr style="background:#e8f4fc">
                    <th>Producto</th>
                    <th>Cantidad</th>
                    <th>Subtotal</th>
                </tr>
            </thead>

            <tbody>
                ${filas}
            </tbody>
        </table>
    `;

    // CORREO PARA EL CLIENTE

    const mensajeCliente = `
        <p>
            Hola,
            <strong>${escaparHTML(cliente.nombre)}</strong>.
        </p>

        <p>
            Hemos recibido tu pedido en Ocean Scooters.
        </p>

        <p>
            <strong>Número de pedido:</strong>
            ${escaparHTML(pedido.id)}
        </p>

        ${tabla}

        <h3>
            Total: ${formatoPrecio(pedido.total)}
        </h3>

        <p>
            <strong>Estado del pago:</strong>
            Pendiente.
        </p>

        <p>
            Tus productos se reservan durante
            <strong>30 minutos</strong>.
        </p>

        <p>
            Si no se confirma el pago dentro
            del plazo, la reserva puede vencer.
        </p>

        <p>
            Este correo confirma el registro
            del pedido, no la recepción del pago.
        </p>

        <p>
            Gracias por elegir Ocean Scooters.
        </p>
    `;

    // CORREO PARA EL ADMINISTRADOR

    const mensajeAdmin = `
        <p>
            Se ha registrado un nuevo pedido.
        </p>

        <p>
            <strong>ID:</strong>
            ${escaparHTML(pedido.id)}
        </p>

        <p>
            <strong>Cliente:</strong>
            ${escaparHTML(cliente.nombre)}
        </p>

        <p>
            <strong>Correo:</strong>
            ${escaparHTML(cliente.correo)}
        </p>

        ${tabla}

        <h3>
            Total: ${formatoPrecio(pedido.total)}
        </h3>

        <p>
            <strong>Estado:</strong>
            Pendiente de pago.
        </p>

        <p>
            Revisa el pedido desde el
            panel de administración.
        </p>
    `;

    const resultados = {};

    // ENVIAR AL CLIENTE

    if (cliente.correo) {
        try {
            await enviarCorreo(
                cliente.correo,
                "Ocean Scooters - Pedido recibido",
                plantillaCorreo(
                    "¡Pedido recibido!",
                    mensajeCliente
                )
            );

            resultados.cliente = "enviado";

        } catch (error) {
            console.error(
                "Error al enviar al cliente:",
                error.message
            );

            resultados.cliente = "error";
        }
    }

    // ENVIAR AL ADMINISTRADOR

    if (CORREO_ADMIN) {
        try {
            await enviarCorreo(
                CORREO_ADMIN,
                `Ocean Scooters - Nuevo pedido ${pedido.id}`,
                plantillaCorreo(
                    "Nuevo pedido registrado",
                    mensajeAdmin
                )
            );

            resultados.administrador = "enviado";

        } catch (error) {
            console.error(
                "Error al enviar al administrador:",
                error.message
            );

            resultados.administrador = "error";
        }
    }

    return resultados;
}

// ==========================================
// NOTIFICACIÓN DE CANCELACIÓN
// ==========================================

async function notificarCancelacion(pedido) {

    const cliente = pedido.cliente || {};

    if (!cliente.correo) {
        return;
    }

    const contenido = `
        <p>
            Hola,
            ${escaparHTML(cliente.nombre)}.
        </p>

        <p>
            Tu pedido
            <strong>${escaparHTML(pedido.id)}</strong>
            ha sido cancelado.
        </p>

        <p>
            Los productos que estaban reservados
            pueden volver a estar disponibles.
        </p>

        <p>
            Si necesitas ayuda, comunícate
            con Ocean Scooters.
        </p>
    `;

    return enviarCorreo(
        cliente.correo,
        "Ocean Scooters - Pedido cancelado",
        plantillaCorreo(
            "Pedido cancelado",
            contenido
        )
    );
}

// ==========================================
// VERIFICAR CONEXIÓN CON ICLOUD
// ==========================================

async function verificarCorreo() {

    if (!SMTP_USER || !SMTP_PASS) {
        throw new Error(
            "Configura SMTP_USER y SMTP_PASS en .env"
        );
    }

    await transporter.verify();

    return true;
}

// ==========================================
// EXPORTAR FUNCIONES
// ==========================================

module.exports = {
    notificarNuevoPedido,
    notificarCancelacion,
    verificarCorreo
};
