-- Ejecutar en la base de pruebas de PostgreSQL, antes de habilitar MP_WEBHOOK_ENABLED.
-- Tabla separada para idempotencia y conciliación de pagos.
CREATE TABLE IF NOT EXISTS public.mp_eventos_pago (
    pago_id TEXT PRIMARY KEY,
    pedido_id UUID NOT NULL REFERENCES public.pedidos(id),
    estado_mp TEXT NOT NULL,
    resultado TEXT NOT NULL,
    importe NUMERIC(12,2),
    moneda VARCHAR(10),
    actualizado_en TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_mp_eventos_pago_pedido ON public.mp_eventos_pago (pedido_id);
