
require("dotenv").config();

const fs = require("fs");
const path = require("path");
const pool = require("./db");

async function migrarProductos() {
    const rutaDatos = path.join(
        __dirname,
        "data",
        "productos.json"
    );

    const rutaOriginal = path.join(
        __dirname,
        "productos.json"
    );

    const ruta = fs.existsSync(rutaDatos)
        ? rutaDatos
        : rutaOriginal;

    if (!fs.existsSync(ruta)) {
        console.error("No se encontró productos.json");
        process.exitCode = 1;
        await pool.end();
        return;
    }

    const productos = JSON.parse(
        fs.readFileSync(ruta, "utf8")
    );

    if (!Array.isArray(productos)) {
        console.error("El archivo debe contener una lista de productos.");
        process.exitCode = 1;
        await pool.end();
        return;
    }

    const cliente = await pool.connect();

    try {
        await cliente.query("BEGIN");

        for (const producto of productos) {
            await cliente.query(
                `INSERT INTO productos
                (id, nombre, descripcion, categoria,
                 precio, stock, imagen)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
                ON CONFLICT (id)
                DO NOTHING`,
                [
                    String(producto.id),
                    producto.nombre,
                    producto.descripcion || "",
                    producto.categoria || "",
                    Number(producto.precio),
                    Number(producto.stock),
                    producto.imagen || ""
                ]
            );
        }

        await cliente.query("COMMIT");

        console.log("================================");
        console.log(" OCEAN SCOOTERS - MIGRACIÓN");
        console.log("================================");
        console.log("Migración terminada.");
        console.log("Productos revisados:", productos.length);

    } catch (error) {
        await cliente.query("ROLLBACK");
        console.error("Error:", error.message);
        process.exitCode = 1;
    } finally {
        cliente.release();
        await pool.end();
    }
}

migrarProductos().catch(error => {
    console.error(error.message);
    process.exitCode = 1;
});
