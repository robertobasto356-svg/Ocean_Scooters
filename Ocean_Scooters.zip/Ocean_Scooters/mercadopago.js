
require("dotenv").config();

const { MercadoPagoConfig, Preference } = require("mercadopago");

if (!process.env.MP_ACCESS_TOKEN) {
  throw new Error("Falta MP_ACCESS_TOKEN en el archivo .env");
}

const client = new MercadoPagoConfig({
  accessToken: process.env.MP_ACCESS_TOKEN,
  options: { timeout: 5000 }
});

const preference = new Preference(client);

module.exports = { client, preference };
