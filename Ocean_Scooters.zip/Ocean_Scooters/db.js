
require("dotenv").config();

const { Pool } = require("pg");

// Comprobar configuración obligatoria
const variables = [
    "DB_HOST",
    "DB_PORT",
    "DB_USER",
    "DB_PASSWORD",
    "DB_NAME"
];

for (const variable of variables) {
    if (!process.env[variable]) {
        throw new Error(
            `Falta configurar ${variable} en el archivo .env`
        );
    }
}

const puerto = Number(process.env.DB_PORT);

if (
    !Number.isInteger(puerto) ||
    puerto < 1 ||
    puerto > 65535
) {
    throw new Error("DB_PORT debe ser un puerto válido.");
}

// Configuración de PostgreSQL
const pool = new Pool({
    host: process.env.DB_HOST,
    port: puerto,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,

    // Pool de conexiones
    max: 10,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 5000,

    // Activar SSL solo si el servidor lo requiere
    ssl: process.env.DB_SSL === "true"
        ? { rejectUnauthorized: true }
        : false
});

// Detectar errores de conexiones inactivas
pool.on("error", (error) => {
    console.error(
        "Error inesperado en PostgreSQL:",
        error.message
    );
});

// Comprobar conexión cuando se necesite
async function verificarConexion() {
    const resultado = await pool.query(
        "SELECT NOW() AS fecha"
    );

    return resultado.rows[0];
}

module.exports = pool;
module.exports.verificarConexion = verificarConexion;
